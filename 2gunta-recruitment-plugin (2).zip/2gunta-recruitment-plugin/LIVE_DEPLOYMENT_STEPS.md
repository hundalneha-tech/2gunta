# 🚀 2gunta Recruitment Plugin - DEPLOYMENT GUIDE
## Production Deployment to 2gunta.com WordPress

**Date:** February 22, 2026  
**Plugin Version:** 1.0.0  
**Target Environment:** WordPress 5.0+ (2gunta.com)

---

## ⚡ Quick Deployment Checklist

```
PRE-DEPLOYMENT
☐ Plugin files verified and complete
☐ Database backups scheduled
☐ Google API credentials ready
☐ SMTP email configuration verified
☐ SSL/TLS certificate active on 2gunta.com
☐ WordPress admin access confirmed

DEPLOYMENT
☐ FTP/SFTP connection established
☐ Plugin files uploaded to /wp-content/plugins/
☐ File permissions set (755 directories, 644 files)
☐ Database tables created (activation hook)
☐ Plugin activated in WordPress Admin

POST-DEPLOYMENT
☐ Google APIs configured in admin settings
☐ Email notifications tested
☐ Career page created with [2gunta_careers] shortcode
☐ Application form page created with [2gunta_application_form] shortcode
☐ Analytics tracking verified (24-hour wait)
☐ reCAPTCHA protection tested
☐ Maps display verified
```

---

## 📋 Step-by-Step Deployment Instructions

### **PHASE 1: PRE-DEPLOYMENT (Complete these before uploading)**

#### Step 1.1: Verify WordPress Environment
```
Requirements:
✓ WordPress 5.0 or later
✓ PHP 7.4 or later
✓ MySQL 5.5.5+ or MariaDB 10.0+
✓ WP-Admin access with install_plugins capability
✓ SSL certificate active (https://)
```

**How to verify:**
1. Log in to 2gunta.com WordPress Admin
2. Go to **Tools → Site Health**
3. Check PHP version, MySQL version, SSL status
4. Note: If PHP < 7.4, request server upgrade

#### Step 1.2: Backup Database
```bash
# SSH into server (if available)
mysqldump -u [username] -p [database_name] > backup_$(date +%Y%m%d_%H%M%S).sql

# Or use WordPress backup plugin:
# WordPress Admin → Tools → Backup
```

#### Step 1.3: Prepare Credentials
Ensure you have these ready:
```
Google APIs:
- Maps API Key: AIzaSyCZLboqyLKt1dVYCqnjPNKA-3SLHGUpefo
- Analytics ID: G-B66X9RBN8T
- reCAPTCHA Site Key: 6LcKJ3QsAAAAAFygnbt0gY1eO9rqv5BGwD8VVuJX
- reCAPTCHA Secret: 6LcKJ3QsAAAAAMzFJc9cs57kf05BSBb8acynm1yC

SMTP/Email:
- SMTP Server: (your provider)
- SMTP Username: (your email)
- SMTP Password: (your password)
- From Email: noreply@2gunta.com
```

---

### **PHASE 2: DEPLOYMENT (Upload plugin files)**

#### Step 2.1: Connect via FTP/SFTP

**Option A: Using FileZilla (GUI)**
```
1. Open FileZilla
2. File → Site Manager
3. Protocol: SFTP
4. Host: 2gunta.com (or your FTP host)
5. Port: 22 (SFTP) or 21 (FTP)
6. Username: [your FTP username]
7. Password: [your FTP password]
8. Click Connect
```

**Option B: Using Command Line (SSH)**
```bash
# Connect to server
ssh username@2gunta.com

# Navigate to plugins directory
cd /home/yourusername/public_html/wp-content/plugins/
```

#### Step 2.2: Upload Plugin Files

**Option A: FileZilla**
```
1. In FileZilla right panel, navigate to: /wp-content/plugins/
2. In left panel, navigate to: C:\Users\woof\2gunta-recruitment-plugin
3. Right-click folder → Upload
4. Select all files and directories
5. Wait for transfer to complete
```

**Option B: Command Line**
```bash
# From your local machine
scp -r C:\Users\woof\2gunta-recruitment-plugin username@2gunta.com:/home/yourusername/public_html/wp-content/plugins/

# Or if on Linux/Mac:
scp -r ~/2gunta-recruitment-plugin username@2gunta.com:/home/yourusername/public_html/wp-content/plugins/
```

#### Step 2.3: Set Correct File Permissions

**Via SSH:**
```bash
cd /wp-content/plugins/2gunta-recruitment-plugin

# Set directory permissions (755 = rwxr-xr-x)
find . -type d -exec chmod 755 {} \;

# Set file permissions (644 = rw-r--r--)
find . -type f -exec chmod 644 {} \;

# Verify ownership (should be www-data or apache)
ls -la | head
```

**Expected output:**
```
drwxr-xr-x  7 www-data www-data  4096 Feb 22
-rw-r--r--  1 www-data www-data  2048 Feb 22 2gunta-recruitment.php
-rw-r--r--  1 www-data www-data  1024 Feb 22 README.md
```

#### Step 2.4: Verify File Upload

**Via SSH:**
```bash
# List plugin directory
ls -la /wp-content/plugins/2gunta-recruitment-plugin/

# Should show:
# .
# ..
# 2gunta-recruitment.php (main plugin file)
# includes/
# assets/
# admin/
# public/
# templates/
# mockups/
# README.md
# And other files
```

---

### **PHASE 3: ACTIVATION (Activate plugin in WordPress)**

#### Step 3.1: Log into WordPress Admin
```
1. Go to https://2gunta.com/wp-admin
2. Log in with your admin credentials
3. You should see the Dashboard
```

#### Step 3.2: Activate Plugin
```
1. Go to: Plugins (left sidebar)
2. Find: "2gunta Recruitment ATS"
3. Status should show: "Inactive"
4. Click: "Activate"
```

**Expected result:**
```
✓ Plugin activated successfully
✓ Notice appears: "2gunta Recruitment ATS activated."
✓ Database tables auto-created
✓ Custom post types registered
```

#### Step 3.3: Verify Activation

Check that EVERYTHING worked:

**Check 1: Plugin appears in active list**
- Plugins page should show "2gunta Recruitment ATS" as "Active"

**Check 2: Database tables created**
- Go to Tools → phpMyAdmin (or use SSH)
- Verify these tables exist in your database:
  ```
  wp_wpc_jobs
  wp_wpc_candidates
  wp_wpc_applications
  wp_wpc_activity_log
  ```

**Check 3: Custom menu appears**
- Left sidebar should show new menu: **Jobs** with submenu items:
  - Settings
  - Jobs
  - Candidates
  - Applications
  - Activity Log

**Check 4: No PHP errors**
- Bottom of page should show: "WordPress has recovered safely"
- OR no notices at all

---

### **PHASE 4: CONFIGURATION (Set up Google APIs & email)**

#### Step 4.1: Configure Google APIs

**Navigate to settings:**
```
1. WordPress Admin → Jobs (left sidebar)
2. Click: Settings
3. Click Tab: "Google APIs Configuration"
```

**Fill in the following fields:**

| Field | Value | From |
|-------|-------|------|
| Google Maps API Key | `AIzaSyCZLboqyLKt1dVYCqnjPNKA-3SLHGUpefo` | Google Cloud Console |
| Google Analytics ID | `G-B66X9RBN8T` | Google Analytics |
| reCAPTCHA Site Key | `6LcKJ3QsAAAAAFygnbt0gY1eO9rqv5BGwD8VVuJX` | reCAPTCHA Admin |
| reCAPTCHA Secret Key | `6LcKJ3QsAAAAAMzFJc9cs57kf05BSBb8acynm1yC` | reCAPTCHA Admin |

**Enable features:**
```
☐ Enable Google Maps on Job Detail Pages
☐ Enable Google Analytics Tracking
☐ Enable reCAPTCHA v3 Protection
```

Check all three boxes, then click **Save Changes**.

**Expected success message:**
```
✓ Settings saved.
✓ Your Google API credentials have been securely stored.
```

#### Step 4.2: Configure Email Notifications

**Navigate to settings:**
```
1. WordPress Admin → Jobs
2. Click: Settings
3. Click Tab: "Email Notifications"
```

**Fill in these fields:**

| Setting | Value |
|---------|-------|
| From Email | `noreply@2gunta.com` |
| From Name | `2gunta Recruitment` |
| Admin Email | `admin@2gunta.com` |
| Enable HTML Emails | ☑ Checked |

**Test email sending:**
```
1. Fill in Test Email field: your-email@example.com
2. Click: "Send Test Email"
3. Check your inbox (wait 10-30 seconds)
4. If received: ✓ Email working
5. If not received: Check SMTP settings
```

#### Step 4.3: Create Career Page

**Create a new WordPress page:**
```
1. Go to Pages → Add New
2. Title: "Careers"
3. In content area, add shortcode:
   [2gunta_careers]
4. Click: Publish
5. Note the URL (e.g., /careers/)
```

**Create a new WordPress page for application form:**
```
1. Go to Pages → Add New
2. Title: "Apply for a Job"
3. In content area, add shortcode:
   [2gunta_application_form]
4. Click: Publish
5. Note the URL (e.g., /apply-for-a-job/)
```

**Link job application form in settings:**
```
1. Go to Jobs → Settings → General Tab
2. Set: Career Page URL → /careers/
3. Set: Application Page URL → /apply-for-a-job/
4. Click: Save Changes
```

---

### **PHASE 5: VERIFICATION (Test everything works)**

#### Step 5.1: Test Career Page

```
1. Go to: https://2gunta.com/careers/
2. Should see: "Careers at 2gunta" heading
3. Should see: Job search form
4. Should see: Job listings (if jobs posted)

✓ If visible: Career page working ✓
```

#### Step 5.2: Test Job Detail Page

```
1. Click on any job listing
2. Should see: Job title, description, meta info
3. Should see: Google Map with location
4. Should see: "Apply Now" button
5. Open browser DevTools → Network tab
6. Look for: Request to maps.googleapis.com
   ✓ If present: Google Maps working ✓
```

#### Step 5.3: Test Application Form

```
1. Click: "Apply Now" button
2. Should see: Application form
3. Fill in fields: Name, email, upload resume
4. Open browser DevTools → Console tab
5. Look for: grecaptcha loading message
   ✓ If present: reCAPTCHA working ✓
```

#### Step 5.4: Test Form Submission

```
1. Fill out application form completely
2. Check "I agree to privacy policy" checkbox
3. Click: "Submit Application"
4. Should see: "Verifying..." button state
5. After ~1 second: "Application submitted successfully!"
6. Should receive: Confirmation email to provided email address

✓ If all work: Form and email working ✓
```

#### Step 5.5: Test Analytics Tracking

```
1. Open DevTools → Network tab
2. Filter by: "google" or "gtag"
3. Visit different pages: careers, job detail, form
4. Should see requests to: www.googletagmanager.com/gtag/js

Note: Analytics dashboard shows data after ~24 hours
✓ Events will appear in GA after 24 hours ✓
```

#### Step 5.6: Test reCAPTCHA Protection

```
1. Open browser Console → Network tab
2. Try to submit application form quickly
3. Watch for reCAPTCHA verification call
4. Should see: POST to www.google.com/recaptcha/api/siteverify

✓ If request visible: reCAPTCHA working ✓
```

---

## ⚠️ Common Issues & Solutions

### Issue 1: Plugin not appearing in admin menu
**Cause:** Plugin file not uploaded correctly  
**Solution:**
```bash
# Via SSH, verify file exists:
ls -la /wp-content/plugins/2gunta-recruitment-plugin/2gunta-recruitment.php

# If missing, re-upload via FTP
```

### Issue 2: "Fatal error: Class not found" on activation
**Cause:** PHP version too old  
**Solution:**
```bash
# Check PHP version:
php -v

# Need PHP 7.4+. If older, request server upgrade.
```

### Issue 3: Database tables not created
**Cause:** Activation hook didn't run  
**Solution:**
```bash
# Deactivate and reactivate plugin:
1. Plugins → Deactivate 2gunta Recruitment ATS
2. Plugins → Activate 2gunta Recruitment ATS
3. Check database for tables
```

### Issue 4: Email not sending
**Cause:** SMTP not configured  
**Solution:**
```bash
# Install WP Mail SMTP plugin:
1. Plugins → Add New
2. Search: "WP Mail SMTP"
3. Install and Activate
4. Configure SMTP credentials
5. Test email again
```

### Issue 5: Google Maps not displaying
**Cause:** API key invalid or API not enabled  
**Solution:**
```bash
1. Check API key in Jobs → Settings
2. Go to Google Cloud Console
3. Verify Maps JavaScript API is "Enabled"
4. Verify API key has Maps API access
5. Check API quotas not exceeded
```

### Issue 6: reCAPTCHA showing errors
**Cause:** Wrong credentials or domain mismatch  
**Solution:**
```bash
1. Google reCAPTCHA Admin Console
2. Verify domain: 2gunta.com is listed
3. Check Site Key matches in settings
4. Check Secret Key is correct
5. Verify reCAPTCHA v3 (not v2)
```

---

## 🎯 Post-Deployment Checklist

```
IMMEDIATELY AFTER DEPLOYMENT
☑ Plugin activated without errors
☑ Database tables created
☑ Admin menu appears
☑ No PHP errors in error log

WITHIN 1 HOUR
☑ Google APIs configured
☑ Email notifications tested
☑ Career page created and visible
☑ Job detail page displays correctly
☑ Application form accessible

WITHIN 24 HOURS
☑ Verify Google Maps display
☑ Test reCAPTCHA on form submission
☑ Check Google Analytics for events
☑ Monitor error logs for issues
☑ Test email notifications from live submissions

ONGOING
☑ Check email delivery logs
☑ Monitor application submissions
☑ Check Analytics funnel metrics
☑ Review activity logs
☑ Monitor for security issues
```

---

## 📞 Support & Rollback

### If Something Goes Wrong

**Option 1: Quick Disable**
```bash
# Via SSH:
mv /wp-content/plugins/2gunta-recruitment-plugin /wp-content/plugins/2gunta-recruitment-plugin-disabled

# Via WordPress:
1. Plugins → Deactivate Plugin
```

**Option 2: Full Rollback**
```bash
# Restore database backup:
mysql -u [username] -p [database_name] < backup_20260222_120000.sql

# Restore from version control (if available)
```

**Option 3: Access Logs**
```bash
# Check error logs:
/var/log/php-errors.log
/var/log/apache2/error.log (Apache)
/var/log/nginx/error.log (Nginx)
```

---

## ✅ Success Criteria

Deployment is **successful** when:

1. ✅ Plugin appears in WordPress admin menu
2. ✅ Careers page displays job listings
3. ✅ Job detail page shows location with interactive map
4. ✅ Application form is accessible and submittable
5. ✅ Confirmation emails are received
6. ✅ Google Analytics shows page views
7. ✅ reCAPTCHA prevents bot submissions
8. ✅ No error messages in WordPress or browser console
9. ✅ All custom post types and taxonomies working
10. ✅ Admin dashboard accessible and functional

---

**Deployment Instructions Complete!**

Your 2gunta Recruitment plugin is now live! 🎉

For ongoing support, refer to:
- [README.md](../README.md) - Plugin overview
- [API_REFERENCE.md](../API_REFERENCE.md) - API endpoints
- [DATABASE_SCHEMA.md](../DATABASE_SCHEMA.md) - Database structure
