<?php
/**
 * Custom Posts Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Register and manage custom post types.
 */
class Posts {

	/**
	 * Register custom post types.
	 */
	public static function register_post_types() {
		// Register Jobs post type.
		register_post_type(
			'2gunta_job',
			array(
				'labels'              => array(
					'name'               => esc_html__( 'Jobs', '2gunta-recruitment' ),
					'singular_name'      => esc_html__( 'Job', '2gunta-recruitment' ),
					'add_new'            => esc_html__( 'Add New Job', '2gunta-recruitment' ),
					'add_new_item'       => esc_html__( 'Add New Job', '2gunta-recruitment' ),
					'edit_item'          => esc_html__( 'Edit Job', '2gunta-recruitment' ),
					'new_item'           => esc_html__( 'New Job', '2gunta-recruitment' ),
					'view_item'          => esc_html__( 'View Job', '2gunta-recruitment' ),
					'search_items'       => esc_html__( 'Search Jobs', '2gunta-recruitment' ),
					'not_found'          => esc_html__( 'No jobs found', '2gunta-recruitment' ),
					'not_found_in_trash' => esc_html__( 'No jobs found in trash', '2gunta-recruitment' ),
				),
				'public'              => true,
				'publicly_queryable'  => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => true,
				'query_var'           => true,
				'rewrite'             => array( 'slug' => 'jobs', 'with_front' => false ),
				'capability_type'     => 'post',
				'has_archive'         => 'jobs',
				'hierarchical'        => false,
				'menu_position'       => 20,
				'supports'            => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' ),
				'taxonomies'          => array( 'job_category', 'job_type' ),
			)
		);

		// Register Candidates post type.
		register_post_type(
			'2gunta_candidate',
			array(
				'labels'              => array(
					'name'               => esc_html__( 'Candidates', '2gunta-recruitment' ),
					'singular_name'      => esc_html__( 'Candidate', '2gunta-recruitment' ),
					'add_new'            => esc_html__( 'Add New Candidate', '2gunta-recruitment' ),
					'add_new_item'       => esc_html__( 'Add New Candidate', '2gunta-recruitment' ),
					'edit_item'          => esc_html__( 'Edit Candidate', '2gunta-recruitment' ),
					'new_item'           => esc_html__( 'New Candidate', '2gunta-recruitment' ),
					'view_item'          => esc_html__( 'View Candidate', '2gunta-recruitment' ),
					'search_items'       => esc_html__( 'Search Candidates', '2gunta-recruitment' ),
					'not_found'          => esc_html__( 'No candidates found', '2gunta-recruitment' ),
					'not_found_in_trash' => esc_html__( 'No candidates found in trash', '2gunta-recruitment' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => true,
				'query_var'           => false,
				'rewrite'             => false,
				'capability_type'     => 'post',
				'has_archive'         => false,
				'hierarchical'        => false,
				'menu_position'       => 21,
				'supports'            => array( 'title', 'editor', 'author', 'thumbnail' ),
			)
		);

		// Register taxonomies.
		register_taxonomy(
			'job_category',
			'2gunta_job',
			array(
				'labels'            => array(
					'name'          => esc_html__( 'Job Categories', '2gunta-recruitment' ),
					'singular_name' => esc_html__( 'Job Category', '2gunta-recruitment' ),
				),
				'hierarchical'      => true,
				'publicly_queryable' => true,
				'show_ui'           => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => 'job-category' ),
			)
		);

		register_taxonomy(
			'job_type',
			'2gunta_job',
			array(
				'labels'            => array(
					'name'          => esc_html__( 'Job Types', '2gunta-recruitment' ),
					'singular_name' => esc_html__( 'Job Type', '2gunta-recruitment' ),
				),
				'hierarchical'      => true,
				'publicly_queryable' => true,
				'show_ui'           => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => 'job-type' ),
			)
		);
	}
}
