<?php
/**
 * Plugin Activator Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Handles plugin activation.
 */
class Activator {

	/**
	 * Activate the plugin.
	 */
	public static function activate() {
		// Create database tables.
		\TwoGunta_Recruitment\Database::create_tables();

		// Register custom post types.
		\TwoGunta_Recruitment\Posts::register_post_types();

		// Flush rewrite rules.
		flush_rewrite_rules();

		// Create default settings.
		self::create_default_settings();
	}

	/**
	 * Create default plugin settings.
	 */
	private static function create_default_settings() {
		$default_settings = array(
			'career_page_title'      => 'Careers at 2gunta',
			'items_per_page'         => 10,
			'max_file_size'          => 5242880, // 5MB.
			'allowed_file_types'     => array( 'pdf', 'doc', 'docx' ),
			'recruitment_email'      => get_option( 'admin_email' ),
			'enable_gdpr'            => 1,
			'candidates_table_name'  => 'wpc_candidates',
			'applications_table_name' => 'wpc_applications',
		);

		foreach ( $default_settings as $key => $value ) {
			if ( ! get_option( '2gunta_recruitment_' . $key ) ) {
				add_option( '2gunta_recruitment_' . $key, $value );
			}
		}
	}
}
