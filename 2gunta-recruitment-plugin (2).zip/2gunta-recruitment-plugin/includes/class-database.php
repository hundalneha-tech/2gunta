<?php
/**
 * Database Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Database setup and management.
 */
class Database {

	/**
	 * Create plugin database tables.
	 */
	public static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// Candidates table.
		$candidates_table = $wpdb->prefix . 'wpc_candidates';
		$sql_candidates   = "CREATE TABLE IF NOT EXISTS $candidates_table (
			id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			user_id BIGINT UNSIGNED,
			first_name VARCHAR(100) NOT NULL,
			last_name VARCHAR(100) NOT NULL,
			email VARCHAR(100) NOT NULL UNIQUE,
			phone VARCHAR(20),
			skills LONGTEXT,
			experience_years INT DEFAULT 0,
			location VARCHAR(100),
			portfolio_url VARCHAR(255),
			tags LONGTEXT,
			notes LONGTEXT,
			rating INT DEFAULT 0,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			KEY user_id (user_id),
			KEY email (email)
		) $charset_collate;";

		// Applications table.
		$applications_table = $wpdb->prefix . 'wpc_applications';
		$sql_applications   = "CREATE TABLE IF NOT EXISTS $applications_table (
			id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			job_id BIGINT UNSIGNED NOT NULL,
			candidate_id BIGINT UNSIGNED NOT NULL,
			resume_url VARCHAR(255),
			cover_letter LONGTEXT,
			status VARCHAR(50) DEFAULT 'new',
			stage VARCHAR(50) DEFAULT 'new',
			rating INT DEFAULT 0,
			notes LONGTEXT,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			KEY job_id (job_id),
			KEY candidate_id (candidate_id),
			KEY status (status)
		) $charset_collate;";

		// Activity log table.
		$activity_table = $wpdb->prefix . 'wpc_activity_log';
		$sql_activity   = "CREATE TABLE IF NOT EXISTS $activity_table (
			id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			user_id BIGINT UNSIGNED NOT NULL,
			candidate_id BIGINT UNSIGNED,
			application_id BIGINT UNSIGNED,
			action VARCHAR(100) NOT NULL,
			details LONGTEXT,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			KEY user_id (user_id),
			KEY candidate_id (candidate_id),
			KEY application_id (application_id)
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql_candidates );
		dbDelta( $sql_applications );
		dbDelta( $sql_activity );
	}

	/**
	 * Log activity.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $candidate_id Candidate ID.
	 * @param int    $application_id Application ID.
	 * @param string $action Action name.
	 * @param string $details Action details.
	 */
	public static function log_activity( $user_id, $candidate_id, $application_id, $action, $details = '' ) {
		global $wpdb;

		$wpdb->insert(
			$wpdb->prefix . 'wpc_activity_log',
			array(
				'user_id'        => $user_id,
				'candidate_id'   => $candidate_id,
				'application_id' => $application_id,
				'action'         => $action,
				'details'        => $details,
			),
			array( '%d', '%d', '%d', '%s', '%s' )
		);
	}
}
