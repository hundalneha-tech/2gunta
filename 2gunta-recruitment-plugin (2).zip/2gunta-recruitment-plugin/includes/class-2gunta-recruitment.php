<?php
/**
 * Main Plugin Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Main class for the plugin.
 */
class Main {

	/**
	 * The instance of this class.
	 *
	 * @var Main
	 */
	protected static $instance = null;

	/**
	 * Get instance of the class.
	 *
	 * @return Main
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->load_dependencies();
		$this->define_hooks();
		$this->init_classes();
	}

	/**
	 * Initialize plugin classes.
	 */
	private function init_classes() {
		// Register custom post types.
		Posts::register_post_types();

		// Initialize plugin classes.
		new Admin();
		new Public_Frontend();
		new API();
		new Privacy();
	}

	/**
	 * Load plugin dependencies.
	 */
	private function load_dependencies() {
		// Core classes.
		require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-posts.php' );
		require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-admin.php' );
		require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-public.php' );
		require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-email.php' );
		require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-api.php' );
		require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-settings.php' );
		require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-database.php' );
		require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-export.php' );
		require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-privacy.php' );
	}

	/**
	 * Define plugin hooks.
	 */
	private function define_hooks() {
		add_action( 'init', array( $this, 'load_plugin_textdomain' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_public_assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	/**
	 * Load plugin text domain.
	 */
	public function load_plugin_textdomain() {
		load_plugin_textdomain(
			'2gunta-recruitment',
			false,
			dirname( GUNTA_RECRUITMENT_PLUGIN_BASENAME ) . '/languages'
		);
	}

	/**
	 * Enqueue public assets.
	 */
	public function enqueue_public_assets() {
		wp_enqueue_style(
			'2gunta-recruitment-public',
			GUNTA_RECRUITMENT_PLUGIN_URL . 'assets/css/public.css',
			array(),
			GUNTA_RECRUITMENT_VERSION
		);

		wp_enqueue_script(
			'2gunta-recruitment-public',
			GUNTA_RECRUITMENT_PLUGIN_URL . 'assets/js/public.js',
			array( 'jquery' ),
			GUNTA_RECRUITMENT_VERSION,
			true
		);

		// Get API keys from settings
		$settings = \TwoGunta_Recruitment\Settings::get_settings();

		// Localize script with data
		wp_localize_script(
			'2gunta-recruitment-public',
			'TwoGuntaRecruitment',
			array(
				'nonce'              => wp_create_nonce( '2gunta-recruitment-nonce' ),
				'ajaxurl'            => admin_url( 'admin-ajax.php' ),
				'recaptchaSiteKey'   => isset( $settings['recaptcha_site_key'] ) ? $settings['recaptcha_site_key'] : '',
				'googleMapsApiKey'   => isset( $settings['google_maps_api_key'] ) ? $settings['google_maps_api_key'] : '',
			)
		);

		// Load reCAPTCHA script if enabled
		if ( isset( $settings['enable_recaptcha'] ) && $settings['enable_recaptcha'] && isset( $settings['recaptcha_site_key'] ) ) {
			wp_enqueue_script(
				'google-recaptcha',
				'https://www.google.com/recaptcha/api.js',
				array(),
				'3.0',
				true
			);
		}

		// Load Google Maps script if enabled
		if ( isset( $settings['enable_google_maps'] ) && $settings['enable_google_maps'] && isset( $settings['google_maps_api_key'] ) ) {
			wp_enqueue_script(
				'google-maps',
				'https://maps.googleapis.com/maps/api/js?key=' . esc_attr( $settings['google_maps_api_key'] ),
				array(),
				'1.0',
				true
			);
		}

		// Load Google Analytics if enabled
		if ( isset( $settings['enable_analytics'] ) && $settings['enable_analytics'] && isset( $settings['google_analytics_id'] ) ) {
			// Google Analytics script
			wp_enqueue_script(
				'google-analytics',
				'https://www.googletagmanager.com/gtag/js?id=' . esc_attr( $settings['google_analytics_id'] ),
				array(),
				'1.0',
				true
			);
			// Inline script for GA initialization
			wp_add_inline_script( 'google-analytics', "
				window.dataLayer = window.dataLayer || [];
				function gtag(){dataLayer.push(arguments);}
				gtag('js', new Date());
				gtag('config', '" . esc_attr( $settings['google_analytics_id'] ) . "');
			" );
		}
	}

	/**
	 * Enqueue admin assets.
	 */
	public function enqueue_admin_assets() {
		wp_enqueue_style(
			'2gunta-recruitment-admin',
			GUNTA_RECRUITMENT_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			GUNTA_RECRUITMENT_VERSION
		);

		wp_enqueue_script(
			'2gunta-recruitment-admin',
			GUNTA_RECRUITMENT_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			GUNTA_RECRUITMENT_VERSION,
			true
		);
	}
}
