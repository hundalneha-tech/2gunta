<?php
/**
 * Public Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Handles public-facing functionality.
 */
class Public_Frontend {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_shortcode( '2gunta_careers', array( $this, 'render_careers_page' ) );
		add_shortcode( '2gunta_application_form', array( $this, 'render_application_form' ) );
		add_action( 'wp_ajax_nopriv_submit_application', array( $this, 'handle_application_submission' ) );
		add_action( 'wp_ajax_submit_application', array( $this, 'handle_application_submission' ) );
		add_action( 'template_redirect', array( $this, 'register_custom_templates' ) );
		add_filter( 'the_content', array( $this, 'render_job_location_map' ), 15 );
	}

	/**
	 * Render careers page shortcode.
	 */
	public function render_careers_page() {
		ob_start();
		?>
		<div class="2gunta-careers-container">
			<h1><?php esc_html_e( 'Careers at 2gunta', '2gunta-recruitment' ); ?></h1>
			
			<div class="jobs-filter">
				<input type="text" id="job-search" placeholder="<?php esc_attr_e( 'Search by title or location...', '2gunta-recruitment' ); ?>" class="form-control" />
			</div>

			<div class="jobs-list" id="jobs-list">
				<?php $this->render_jobs_list(); ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render jobs list.
	 */
	private function render_jobs_list() {
		$args = array(
			'post_type'      => '2gunta_job',
			'posts_per_page' => get_option( '2gunta_recruitment_items_per_page', 10 ),
			'post_status'    => 'publish',
		);

		$jobs = new \WP_Query( $args );

		if ( $jobs->have_posts() ) {
			while ( $jobs->have_posts() ) {
				$jobs->the_post();
				$location = get_post_meta( get_the_ID(), '_job_location', true );
				$salary   = get_post_meta( get_the_ID(), '_job_salary', true );
				?>
				<div class="job-card">
					<h3><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h3>
					<p class="job-meta">
						<?php if ( $location ) : ?>
							<span class="job-location"><i class="icon-location"></i> <?php echo esc_html( $location ); ?></span>
						<?php endif; ?>
						<?php if ( $salary ) : ?>
							<span class="job-salary"><i class="icon-salary"></i> <?php echo esc_html( $salary ); ?></span>
						<?php endif; ?>
					</p>
					<p class="job-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
					<a href="<?php echo esc_url( get_permalink() ); ?>" class="button button-primary">
						<?php esc_html_e( 'View & Apply', '2gunta-recruitment' ); ?>
					</a>
				</div>
				<?php
			}
			wp_reset_postdata();
		} else {
			echo '<p>' . esc_html__( 'No jobs available at the moment', '2gunta-recruitment' ) . '</p>';
		}
	}

	/**
	 * Render application form shortcode.
	 */
	public function render_application_form() {
		if ( ! is_singular( '2gunta_job' ) ) {
			return '';
		}

		ob_start();
		?>
		<form class="application-form" id="2gunta-application-form" method="post" enctype="multipart/form-data">
			<?php wp_nonce_field( '2gunta_apply_nonce', 'nonce' ); ?>
			
			<input type="hidden" name="job_id" value="<?php echo esc_attr( get_the_ID() ); ?>" />

			<div class="form-group">
				<label for="first_name"><?php esc_html_e( 'First Name *', '2gunta-recruitment' ); ?></label>
				<input type="text" id="first_name" name="first_name" required class="form-control" />
			</div>

			<div class="form-group">
				<label for="last_name"><?php esc_html_e( 'Last Name *', '2gunta-recruitment' ); ?></label>
				<input type="text" id="last_name" name="last_name" required class="form-control" />
			</div>

			<div class="form-group">
				<label for="email"><?php esc_html_e( 'Email *', '2gunta-recruitment' ); ?></label>
				<input type="email" id="email" name="email" required class="form-control" />
			</div>

			<div class="form-group">
				<label for="phone"><?php esc_html_e( 'Phone Number', '2gunta-recruitment' ); ?></label>
				<input type="tel" id="phone" name="phone" class="form-control" />
			</div>

			<div class="form-group">
				<label for="location"><?php esc_html_e( 'Location', '2gunta-recruitment' ); ?></label>
				<input type="text" id="location" name="location" class="form-control" />
			</div>

			<div class="form-group">
				<label for="resume"><?php esc_html_e( 'Resume/CV *', '2gunta-recruitment' ); ?></label>
				<input type="file" id="resume" name="resume" required accept=".pdf,.doc,.docx" class="form-control" />
				<small><?php esc_html_e( 'PDF, DOC, or DOCX (max 5MB)', '2gunta-recruitment' ); ?></small>
			</div>

			<div class="form-group">
				<label for="cover_letter"><?php esc_html_e( 'Cover Letter', '2gunta-recruitment' ); ?></label>
				<textarea id="cover_letter" name="cover_letter" rows="5" class="form-control"></textarea>
			</div>

			<div class="form-group">
				<label for="experience"><?php esc_html_e( 'Years of Experience', '2gunta-recruitment' ); ?></label>
				<input type="number" id="experience" name="experience" min="0" class="form-control" />
			</div>

			<div class="form-group">
				<label class="checkbox">
					<input type="checkbox" name="agree_gdpr" required />
					<?php esc_html_e( 'I agree to the privacy policy and terms *', '2gunta-recruitment' ); ?>
				</label>
			</div>

			<?php wp_nonce_field( '2gunta_apply_nonce', '2gunta_apply_nonce' ); ?>
			
			<!-- reCAPTCHA field (hidden, added by reCAPTCHA v3) -->
			<input type="hidden" name="recaptcha_token" id="recaptcha_token" />

			<button type="submit" class="button button-primary button-large" id="submit-button">
				<?php esc_html_e( 'Submit Application', '2gunta-recruitment' ); ?>
			</button>
		</form>
		<?php
		return ob_get_clean();
	}

	/**
	 * Handle application submission.
	 */
	public function handle_application_submission() {
		check_ajax_referer( '2gunta_apply_nonce', 'nonce' );

		// Verify reCAPTCHA token if enabled
		$settings = \TwoGunta_Recruitment\Settings::get_settings();
		if ( isset( $settings['enable_recaptcha'] ) && $settings['enable_recaptcha'] && isset( $settings['recaptcha_secret_key'] ) ) {
			if ( ! isset( $_POST['recaptcha_token'] ) || empty( $_POST['recaptcha_token'] ) ) {
				wp_send_json_error( esc_html__( 'reCAPTCHA verification failed', '2gunta-recruitment' ) );
			}

			$recaptcha_token = sanitize_text_field( $_POST['recaptcha_token'] );
			$recaptcha_secret = $settings['recaptcha_secret_key'];

			// Verify reCAPTCHA token with Google
			$response = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array(
				'body' => array(
					'secret'   => $recaptcha_secret,
					'response' => $recaptcha_token,
				),
			) );

			if ( is_wp_error( $response ) ) {
				wp_send_json_error( esc_html__( 'reCAPTCHA verification error', '2gunta-recruitment' ) );
			}

			$response_body = json_decode( wp_remote_retrieve_body( $response ), true );

			// Check if verification was successful (score > 0.5)
			if ( ! isset( $response_body['success'] ) || ! $response_body['success'] || 
				 ( isset( $response_body['score'] ) && $response_body['score'] < 0.5 ) ) {
				wp_send_json_error( esc_html__( 'Submission appears to be from a bot. Please try again.', '2gunta-recruitment' ) );
			}
		}

		// Validate form submission.
		if ( ! isset( $_POST['job_id'] ) || ! isset( $_POST['email'] ) ) {
			wp_send_json_error( esc_html__( 'Invalid submission', '2gunta-recruitment' ) );
		}

		$job_id  = intval( $_POST['job_id'] );
		$email   = sanitize_email( $_POST['email'] );
		$first_name = sanitize_text_field( $_POST['first_name'] );
		$last_name  = sanitize_text_field( $_POST['last_name'] );
		$phone      = sanitize_text_field( $_POST['phone'] ?? '' );
		$location   = sanitize_text_field( $_POST['location'] ?? '' );
		$experience = intval( $_POST['experience'] ?? 0 );
		$cover_letter = sanitize_textarea_field( $_POST['cover_letter'] ?? '' );

		// Handle file upload.
		$resume_url = '';
		if ( ! empty( $_FILES['resume'] ) ) {
			$resume_url = $this->handle_file_upload( $_FILES['resume'] );
			if ( ! $resume_url ) {
				wp_send_json_error( esc_html__( 'Error uploading resume', '2gunta-recruitment' ) );
			}
		}

		global $wpdb;

		// Create or get candidate.
		$candidate_id = $this->get_or_create_candidate( $first_name, $last_name, $email, $phone, $location, $experience );

		// Create application.
		$wpdb->insert(
			$wpdb->prefix . 'wpc_applications',
			array(
				'job_id'        => $job_id,
				'candidate_id'  => $candidate_id,
				'resume_url'    => $resume_url,
				'cover_letter'  => $cover_letter,
				'status'        => 'new',
			),
			array( '%d', '%d', '%s', '%s', '%s' )
		);

		// Send confirmation email.
		Email::send_application_received( $email, $first_name );

		// Send admin notification.
		Email::send_admin_notification( $job_id, $email, $first_name . ' ' . $last_name );

		// Track conversion in Google Analytics
		if ( isset( $settings['enable_analytics'] ) && $settings['enable_analytics'] ) {
			// Analytics tracking happens client-side, but we can log server-side if needed
		}

		wp_send_json_success( esc_html__( 'Application submitted successfully', '2gunta-recruitment' ) );
	}

	/**
	 * Handle file upload.
	 *
	 * @param array $file File array.
	 * @return string File URL or empty string on error.
	 */
	private function handle_file_upload( $file ) {
		$allowed_types = get_option( '2gunta_recruitment_allowed_file_types', array( 'pdf', 'doc', 'docx' ) );
		$max_size      = get_option( '2gunta_recruitment_max_file_size', 5242880 );

		if ( $file['size'] > $max_size ) {
			return '';
		}

		$file_extension = pathinfo( $file['name'], PATHINFO_EXTENSION );
		if ( ! in_array( strtolower( $file_extension ), $allowed_types ) ) {
			return '';
		}

		$upload_dir = wp_upload_dir();
		$upload_path = trailingslashit( $upload_dir['path'] ) . 'resumes';

		if ( ! is_dir( $upload_path ) ) {
			mkdir( $upload_path, 0755, true );
		}

		$filename = sanitize_file_name( time() . '_' . $file['name'] );
		$filepath = $upload_path . '/' . $filename;

		if ( move_uploaded_file( $file['tmp_name'], $filepath ) ) {
			return $upload_dir['url'] . '/resumes/' . $filename;
		}

		return '';
	}

	/**
	 * Get or create candidate.
	 *
	 * @param string $first_name First name.
	 * @param string $last_name Last name.
	 * @param string $email Email.
	 * @param string $phone Phone.
	 * @param string $location Location.
	 * @param int    $experience Experience years.
	 * @return int Candidate ID.
	 */
	private function get_or_create_candidate( $first_name, $last_name, $email, $phone, $location, $experience ) {
		global $wpdb;

		// Check if candidate exists.
		$candidate = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}wpc_candidates WHERE email = %s",
				$email
			)
		);

		if ( $candidate ) {
			return $candidate->id;
		}

		// Create new candidate.
		$wpdb->insert(
			$wpdb->prefix . 'wpc_candidates',
			array(
				'first_name'      => $first_name,
				'last_name'       => $last_name,
				'email'           => $email,
				'phone'           => $phone,
				'location'        => $location,
				'experience_years' => $experience,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d' )
		);

		return $wpdb->insert_id;
	}

	/**
	 * Register custom templates.
	 */
	public function register_custom_templates() {
		// Template registration logic here.
	}

	/**
	 * Display Google Map for job location on job detail pages.
	 *
	 * @param string $content The post content.
	 * @return string Modified post content with map.
	 */
	public function render_job_location_map( $content ) {
		// Only display on job single posts
		if ( ! is_singular( '2gunta_job' ) ) {
			return $content;
		}

		$settings = Settings::get_settings();

		// Check if Google Maps is enabled
		if ( ! isset( $settings['enable_google_maps'] ) || ! $settings['enable_google_maps'] || 
			 ! isset( $settings['google_maps_api_key'] ) || empty( $settings['google_maps_api_key'] ) ) {
			return $content;
		}

		$location = get_post_meta( get_the_ID(), '_job_location', true );
		if ( ! $location ) {
			return $content;
		}

		ob_start();
		?>
		<div class="job-location-map">
			<h3><?php esc_html_e( 'Job Location', '2gunta-recruitment' ); ?></h3>
			<div id="map" style="height: 400px; margin: 20px 0; border-radius: 5px;"></div>
			<p class="location-address"><?php echo esc_html( $location ); ?></p>
			<script>
				(function() {
					// Initialize map only if Google Maps API is loaded
					if (typeof google !== 'undefined' && google.maps) {
						var location = '<?php echo esc_js( $location ); ?>';
						var geocoder = new google.maps.Geocoder();
						
						geocoder.geocode({'address': location}, function(results, status) {
							if (status === google.maps.GeocoderStatus.OK) {
								var map = new google.maps.Map(
									document.getElementById('map'),
									{
										zoom: 15,
										center: results[0].geometry.location
									}
								);
								
								new google.maps.Marker({
									map: map,
									position: results[0].geometry.location,
									title: location
								});
							}
						});
					}
				})();
			</script>
		</div>
		<?php
		$map_html = ob_get_clean();

		return $content . $map_html;
	}
}
