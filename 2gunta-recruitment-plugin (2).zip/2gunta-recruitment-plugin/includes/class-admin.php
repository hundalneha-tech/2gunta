<?php
/**
 * Admin Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Handles admin functionality.
 */
class Admin {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post_2gunta_job', array( $this, 'save_job_meta' ) );
		add_action( 'wp_ajax_get_applications', array( $this, 'get_applications' ) );
		add_action( 'wp_ajax_update_application_status', array( $this, 'update_application_status' ) );
		add_action( 'wp_ajax_send_email_template', array( $this, 'send_email_template' ) );
		add_action( 'wp_ajax_export_candidates_csv', array( $this, 'export_candidates_csv' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Add admin menu.
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'edit.php?post_type=2gunta_job',
			esc_html__( 'Recruitment Dashboard', '2gunta-recruitment' ),
			esc_html__( 'Dashboard', '2gunta-recruitment' ),
			'manage_options',
			'2gunta-recruitment-dashboard',
			array( $this, 'render_dashboard' )
		);

		add_submenu_page(
			'edit.php?post_type=2gunta_job',
			esc_html__( 'Candidates', '2gunta-recruitment' ),
			esc_html__( 'Candidates', '2gunta-recruitment' ),
			'manage_options',
			'2gunta-recruitment-candidates',
			array( $this, 'render_candidates' )
		);

		add_submenu_page(
			'edit.php?post_type=2gunta_job',
			esc_html__( 'Settings', '2gunta-recruitment' ),
			esc_html__( 'Settings', '2gunta-recruitment' ),
			'manage_options',
			'2gunta-recruitment-settings',
			array( $this, 'render_settings' )
		);
	}

	/**
	 * Render admin dashboard.
	 */
	public function render_dashboard() {
		global $wpdb;

		// Get statistics.
		$jobs_count      = wp_count_posts( '2gunta_job' );
		$applications    = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpc_applications" );
		$candidates      = $wpdb->get_var( "SELECT COUNT(DISTINCT candidate_id) FROM {$wpdb->prefix}wpc_applications" );

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Recruitment Dashboard', '2gunta-recruitment' ); ?></h1>
			
			<div class="dashboard-stats">
				<div class="stat-box">
					<h3><?php echo esc_html( $jobs_count->publish ); ?></h3>
					<p><?php esc_html_e( 'Active Jobs', '2gunta-recruitment' ); ?></p>
				</div>
				<div class="stat-box">
					<h3><?php echo esc_html( $applications ); ?></h3>
					<p><?php esc_html_e( 'Total Applications', '2gunta-recruitment' ); ?></p>
				</div>
				<div class="stat-box">
					<h3><?php echo esc_html( $candidates ); ?></h3>
					<p><?php esc_html_e( 'Unique Candidates', '2gunta-recruitment' ); ?></p>
				</div>
			</div>

			<h2><?php esc_html_e( 'Recent Applications', '2gunta-recruitment' ); ?></h2>
			<div id="recent-applications">
				<?php $this->render_recent_applications(); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render recent applications.
	 */
	private function render_recent_applications() {
		global $wpdb;

		$applications = $wpdb->get_results(
			"SELECT 
				a.*,
				p.post_title as job_title,
				c.first_name,
				c.last_name
			FROM {$wpdb->prefix}wpc_applications a
			LEFT JOIN $wpdb->posts p ON a.job_id = p.ID
			LEFT JOIN {$wpdb->prefix}wpc_candidates c ON a.candidate_id = c.id
			ORDER BY a.created_at DESC
			LIMIT 10"
		);

		if ( empty( $applications ) ) {
			echo '<p>' . esc_html__( 'No applications yet', '2gunta-recruitment' ) . '</p>';
			return;
		}

		?>
		<table class="widefat">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Candidate', '2gunta-recruitment' ); ?></th>
					<th><?php esc_html_e( 'Job', '2gunta-recruitment' ); ?></th>
					<th><?php esc_html_e( 'Status', '2gunta-recruitment' ); ?></th>
					<th><?php esc_html_e( 'Date', '2gunta-recruitment' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $applications as $app ) : ?>
					<tr>
						<td><?php echo esc_html( $app->first_name . ' ' . $app->last_name ); ?></td>
						<td><?php echo esc_html( $app->job_title ); ?></td>
						<td><span class="status-badge status-<?php echo esc_attr( $app->status ); ?>"><?php echo esc_html( ucfirst( $app->status ) ); ?></span></td>
						<td><?php echo esc_html( $app->created_at ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Render candidates page.
	 */
	public function render_candidates() {
		global $wpdb;
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Candidates', '2gunta-recruitment' ); ?></h1>
			
			<table class="widefat">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Name', '2gunta-recruitment' ); ?></th>
						<th><?php esc_html_e( 'Email', '2gunta-recruitment' ); ?></th>
						<th><?php esc_html_e( 'Location', '2gunta-recruitment' ); ?></th>
						<th><?php esc_html_e( 'Experience', '2gunta-recruitment' ); ?></th>
						<th><?php esc_html_e( 'Actions', '2gunta-recruitment' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php $this->render_candidates_list(); ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Render candidates list.
	 */
	private function render_candidates_list() {
		global $wpdb;

		$candidates = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}wpc_candidates ORDER BY created_at DESC LIMIT 20"
		);

		if ( empty( $candidates ) ) {
			echo '<tr><td colspan="5">' . esc_html__( 'No candidates found', '2gunta-recruitment' ) . '</td></tr>';
			return;
		}

		foreach ( $candidates as $candidate ) {
			?>
			<tr>
				<td><?php echo esc_html( $candidate->first_name . ' ' . $candidate->last_name ); ?></td>
				<td><?php echo esc_html( $candidate->email ); ?></td>
				<td><?php echo esc_html( $candidate->location ); ?></td>
				<td><?php echo esc_html( $candidate->experience_years . ' years' ); ?></td>
				<td>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=2gunta-recruitment-candidate&id=' . $candidate->id ) ); ?>" class="button button-small">
						<?php esc_html_e( 'View', '2gunta-recruitment' ); ?>
					</a>
				</td>
			</tr>
			<?php
		}
	}

	/**
	 * Render settings page.
	 */
	public function render_settings() {
		$options = get_option( '2gunta_recruitment_settings', array() );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Recruitment Settings', '2gunta-recruitment' ); ?></h1>
			
			<form method="post" action="options.php">
				<?php settings_fields( '2gunta_recruitment_settings' ); ?>
				<?php do_settings_sections( '2gunta_recruitment_settings' ); ?>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Register settings.
	 */
	public function register_settings() {
		register_setting( '2gunta_recruitment_settings', '2gunta_recruitment_settings' );

		add_settings_section(
			'2gunta_recruitment_general',
			esc_html__( 'General Settings', '2gunta-recruitment' ),
			array( $this, 'render_general_section' ),
			'2gunta_recruitment_settings'
		);

		add_settings_field(
			'career_page_title',
			esc_html__( 'Career Page Title', '2gunta-recruitment' ),
			array( $this, 'render_career_page_title_field' ),
			'2gunta_recruitment_settings',
			'2gunta_recruitment_general'
		);

		// Google APIs Section
		add_settings_section(
			'2gunta_recruitment_google_apis',
			esc_html__( 'Google APIs Configuration', '2gunta-recruitment' ),
			array( $this, 'render_google_apis_section' ),
			'2gunta_recruitment_settings'
		);

		// Google Maps API Key
		add_settings_field(
			'google_maps_api_key',
			esc_html__( 'Google Maps API Key', '2gunta-recruitment' ),
			array( $this, 'render_google_maps_api_field' ),
			'2gunta_recruitment_settings',
			'2gunta_recruitment_google_apis'
		);

		// Google Analytics ID
		add_settings_field(
			'google_analytics_id',
			esc_html__( 'Google Analytics Measurement ID', '2gunta-recruitment' ),
			array( $this, 'render_google_analytics_field' ),
			'2gunta_recruitment_settings',
			'2gunta_recruitment_google_apis'
		);

		// reCAPTCHA Site Key
		add_settings_field(
			'recaptcha_site_key',
			esc_html__( 'reCAPTCHA Site Key', '2gunta-recruitment' ),
			array( $this, 'render_recaptcha_site_key_field' ),
			'2gunta_recruitment_settings',
			'2gunta_recruitment_google_apis'
		);

		// reCAPTCHA Secret Key
		add_settings_field(
			'recaptcha_secret_key',
			esc_html__( 'reCAPTCHA Secret Key', '2gunta-recruitment' ),
			array( $this, 'render_recaptcha_secret_key_field' ),
			'2gunta_recruitment_settings',
			'2gunta_recruitment_google_apis'
		);
	}

	/**
	 * Render general section.
	 */
	public function render_general_section() {
		echo '<p>' . esc_html__( 'Configure your recruitment settings', '2gunta-recruitment' ) . '</p>';
	}

	/**
	 * Render career page title field.
	 */
	public function render_career_page_title_field() {
		$value = get_option( '2gunta_recruitment_career_page_title', 'Careers at 2gunta' );
		?>
		<input type="text" name="2gunta_recruitment_career_page_title" value="<?php echo esc_attr( $value ); ?>" />
		<?php
	}

	/**
	 * Render Google APIs section.
	 */
	public function render_google_apis_section() {
		echo '<p>' . esc_html__( 'Configure your Google APIs for maps, analytics, and spam protection', '2gunta-recruitment' ) . '</p>';
	}

	/**
	 * Render Google Maps API Key field.
	 */
	public function render_google_maps_api_field() {
		$value = get_option( '2gunta_recruitment_google_maps_api_key', '' );
		?>
		<input type="password" name="2gunta_recruitment_google_maps_api_key" value="<?php echo esc_attr( $value ); ?>" style="width: 100%; max-width: 400px;" />
		<p class="description"><?php esc_html_e( 'Get this from: https://console.cloud.google.com/ → Enable Maps JavaScript API → Create Credentials', '2gunta-recruitment' ); ?></p>
		<?php
	}

	/**
	 * Render Google Analytics Measurement ID field.
	 */
	public function render_google_analytics_field() {
		$value = get_option( '2gunta_recruitment_google_analytics_id', '' );
		?>
		<input type="text" name="2gunta_recruitment_google_analytics_id" value="<?php echo esc_attr( $value ); ?>" placeholder="G-XXXXXXXXXX" style="width: 100%; max-width: 400px;" />
		<p class="description"><?php esc_html_e( 'Format: G-XXXXXXXXXX. Get this from: https://analytics.google.com/', '2gunta-recruitment' ); ?></p>
		<?php
	}

	/**
	 * Render reCAPTCHA Site Key field.
	 */
	public function render_recaptcha_site_key_field() {
		$value = get_option( '2gunta_recruitment_recaptcha_site_key', '' );
		?>
		<input type="password" name="2gunta_recruitment_recaptcha_site_key" value="<?php echo esc_attr( $value ); ?>" style="width: 100%; max-width: 400px;" />
		<p class="description"><?php esc_html_e( 'This is the SITE KEY (public). Get from: https://www.google.com/recaptcha/admin', '2gunta-recruitment' ); ?></p>
		<?php
	}

	/**
	 * Render reCAPTCHA Secret Key field.
	 */
	public function render_recaptcha_secret_key_field() {
		$value = get_option( '2gunta_recruitment_recaptcha_secret_key', '' );
		?>
		<input type="password" name="2gunta_recruitment_recaptcha_secret_key" value="<?php echo esc_attr( $value ); ?>" style="width: 100%; max-width: 400px;" />
		<p class="description"><?php esc_html_e( 'This is the SECRET KEY (private). Get from: https://www.google.com/recaptcha/admin - KEEP THIS SECURE!', '2gunta-recruitment' ); ?></p>
		<?php
	}

	/**
	 * Add meta boxes.
	 */
	public function add_meta_boxes() {
		add_meta_box(
			'2gunta_job_details',
			esc_html__( 'Job Details', '2gunta-recruitment' ),
			array( $this, 'render_job_details_meta_box' ),
			'2gunta_job'
		);
	}

	/**
	 * Render job details meta box.
	 */
	public function render_job_details_meta_box( $post ) {
		wp_nonce_field( 'save_job_meta_nonce', 'job_meta_nonce' );

		$job_location = get_post_meta( $post->ID, '_job_location', true );
		$job_salary    = get_post_meta( $post->ID, '_job_salary', true );
		$job_type_meta = get_post_meta( $post->ID, '_job_type_custom', true );

		?>
		<div class="job-details-form">
			<p>
				<label for="job_location"><?php esc_html_e( 'Location', '2gunta-recruitment' ); ?>:</label>
				<input type="text" id="job_location" name="job_location" value="<?php echo esc_attr( $job_location ); ?>" class="widefat" />
			</p>
			<p>
				<label for="job_salary"><?php esc_html_e( 'Salary Range', '2gunta-recruitment' ); ?>:</label>
				<input type="text" id="job_salary" name="job_salary" value="<?php echo esc_attr( $job_salary ); ?>" class="widefat" placeholder="e.g., $50,000 - $70,000" />
			</p>
			<p>
				<label for="job_type_custom"><?php esc_html_e( 'Job Type', '2gunta-recruitment' ); ?>:</label>
				<select id="job_type_custom" name="job_type_custom" class="widefat">
					<option value="" <?php selected( $job_type_meta, '' ); ?>>Select</option>
					<option value="full-time" <?php selected( $job_type_meta, 'full-time' ); ?>>Full-Time</option>
					<option value="part-time" <?php selected( $job_type_meta, 'part-time' ); ?>>Part-Time</option>
					<option value="contract" <?php selected( $job_type_meta, 'contract' ); ?>>Contract</option>
					<option value="freelance" <?php selected( $job_type_meta, 'freelance' ); ?>>Freelance</option>
				</select>
			</p>
		</div>
		<?php
	}

	/**
	 * Save job meta.
	 *
	 * @param int $post_id Post ID.
	 */
	public function save_job_meta( $post_id ) {
		if ( ! isset( $_POST['job_meta_nonce'] ) || ! wp_verify_nonce( $_POST['job_meta_nonce'], 'save_job_meta_nonce' ) ) {
			return;
		}

		if ( isset( $_POST['job_location'] ) ) {
			update_post_meta( $post_id, '_job_location', sanitize_text_field( $_POST['job_location'] ) );
		}

		if ( isset( $_POST['job_salary'] ) ) {
			update_post_meta( $post_id, '_job_salary', sanitize_text_field( $_POST['job_salary'] ) );
		}

		if ( isset( $_POST['job_type_custom'] ) ) {
			update_post_meta( $post_id, '_job_type_custom', sanitize_text_field( $_POST['job_type_custom'] ) );
		}
	}

	/**
	 * Get applications via AJAX.
	 */
	public function get_applications() {
		check_ajax_referer( '2gunta-recruitment-nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		global $wpdb;

		$job_id = isset( $_POST['job_id'] ) ? intval( $_POST['job_id'] ) : 0;

		$applications = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.*, c.first_name, c.last_name, c.email FROM {$wpdb->prefix}wpc_applications a
				LEFT JOIN {$wpdb->prefix}wpc_candidates c ON a.candidate_id = c.id
				WHERE a.job_id = %d
				ORDER BY a.created_at DESC",
				$job_id
			)
		);

		wp_send_json_success( $applications );
	}

	/**
	 * Update application status via AJAX.
	 */
	public function update_application_status() {
		check_ajax_referer( '2gunta-recruitment-nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		global $wpdb;

		$application_id = isset( $_POST['application_id'] ) ? intval( $_POST['application_id'] ) : 0;
		$status         = isset( $_POST['status'] ) ? sanitize_text_field( $_POST['status'] ) : '';

		$wpdb->update(
			$wpdb->prefix . 'wpc_applications',
			array( 'status' => $status ),
			array( 'id' => $application_id ),
			array( '%s' ),
			array( '%d' )
		);

		// Log activity.
		Database::log_activity(
			get_current_user_id(),
			0,
			$application_id,
			'status_changed',
			$status
		);

		wp_send_json_success();
	}

	/**
	 * Send email template via AJAX.
	 */
	public function send_email_template() {
		check_ajax_referer( '2gunta-recruitment-nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		$application_id = isset( $_POST['application_id'] ) ? intval( $_POST['application_id'] ) : 0;
		$template       = isset( $_POST['template'] ) ? sanitize_text_field( $_POST['template'] ) : '';

		// Send email.
		Email::send_template_email( $application_id, $template );

		wp_send_json_success();
	}

	/**
	 * Export candidates to CSV via AJAX.
	 */
	public function export_candidates_csv() {
		check_ajax_referer( '2gunta-recruitment-nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		Export::export_candidates_csv();
	}
}

new Admin();
