<?php
/**
 * Settings Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Plugin settings management.
 */
class Settings {

	/**
	 * Get all settings.
	 *
	 * @return array
	 */
	public static function get_settings() {
		return array(
			'career_page_title'       => get_option( '2gunta_recruitment_career_page_title', 'Careers' ),
			'recruitment_email'       => get_option( '2gunta_recruitment_email', get_option( 'admin_email' ) ),
			'items_per_page'          => get_option( '2gunta_recruitment_items_per_page', 10 ),
			'max_file_size'           => get_option( '2gunta_recruitment_max_file_size', 5242880 ),
			'allowed_file_types'      => get_option( '2gunta_recruitment_allowed_file_types', array( 'pdf', 'doc', 'docx' ) ),
			'enable_gdpr'             => get_option( '2gunta_recruitment_enable_gdpr', 1 ),
			'google_maps_api_key'     => get_option( '2gunta_recruitment_google_maps_api_key', '' ),
			'google_analytics_id'     => get_option( '2gunta_recruitment_google_analytics_id', '' ),
			'recaptcha_site_key'      => get_option( '2gunta_recruitment_recaptcha_site_key', '' ),
			'recaptcha_secret_key'    => get_option( '2gunta_recruitment_recaptcha_secret_key', '' ),
			'enable_google_maps'      => get_option( '2gunta_recruitment_enable_google_maps', 1 ),
			'enable_analytics'        => get_option( '2gunta_recruitment_enable_analytics', 1 ),
			'enable_recaptcha'        => get_option( '2gunta_recruitment_enable_recaptcha', 1 ),
		);
	}

	/**
	 * Update settings.
	 *
	 * @param array $settings Settings to update.
	 */
	public static function update_settings( $settings ) {
		foreach ( $settings as $key => $value ) {
			update_option( '2gunta_recruitment_' . $key, $value );
		}
	}
}
