<?php
/**
 * Plugin Deactivator Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Handles plugin deactivation.
 */
class Deactivator {

	/**
	 * Deactivate the plugin.
	 */
	public static function deactivate() {
		// Flush rewrite rules.
		flush_rewrite_rules();
	}
}
