<?php
/**
 * Email Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Email functionality.
 */
class Email {

	/**
	 * Send application received email.
	 *
	 * @param string $email Candidate email.
	 * @param string $name Candidate name.
	 */
	public static function send_application_received( $email, $name ) {
		$subject = esc_html__( 'Application Received', '2gunta-recruitment' );
		$body    = sprintf(
			esc_html__( 'Dear %s,\n\nThank you for submitting your application. We have received it and will review it shortly.\n\nBest Regards,\n2gunta Team', '2gunta-recruitment' ),
			$name
		);

		wp_mail( $email, $subject, $body );
	}

	/**
	 * Send admin notification.
	 *
	 * @param int    $job_id Job ID.
	 * @param string $email Candidate email.
	 * @param string $name Candidate name.
	 */
	public static function send_admin_notification( $job_id, $email, $name ) {
		$job_title = get_the_title( $job_id );
		$admin_email = get_option( 'admin_email' );
		$subject = sprintf( esc_html__( 'New Application: %s', '2gunta-recruitment' ), $job_title );
		$body = sprintf(
			esc_html__( 'New application received!\n\nCandidate: %s\nEmail: %s\nJob: %s', '2gunta-recruitment' ),
			$name,
			$email,
			$job_title
		);

		wp_mail( $admin_email, $subject, $body );
	}

	/**
	 * Send template email.
	 *
	 * @param int    $application_id Application ID.
	 * @param string $template Template name.
	 */
	public static function send_template_email( $application_id, $template ) {
		global $wpdb;

		$application = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpc_applications WHERE id = %d",
				$application_id
			)
		);

		if ( ! $application ) {
			return;
		}

		$candidate = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpc_candidates WHERE id = %d",
				$application->candidate_id
			)
		);

		if ( ! $candidate ) {
			return;
		}

		$templates = array(
			'interview_invite' => esc_html__( 'You are invited for an interview for the position.', '2gunta-recruitment' ),
			'rejection'        => esc_html__( 'Unfortunately, we have decided not to move forward with your application.', '2gunta-recruitment' ),
			'offer'            => esc_html__( 'We are pleased to offer you the position.', '2gunta-recruitment' ),
		);

		$subject = 'Application Update';
		$body    = isset( $templates[ $template ] ) ? $templates[ $template ] : '';

		wp_mail( $candidate->email, $subject, $body );
	}
}
