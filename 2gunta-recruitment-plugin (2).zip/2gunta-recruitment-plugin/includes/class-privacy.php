<?php
/**
 * Privacy Class - GDPR Compliance
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Handle GDPR and privacy compliance.
 */
class Privacy {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_privacy_tabs' ) );
	}

	/**
	 * Register privacy page tabs.
	 */
	public function register_privacy_tabs() {
		if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
			wp_add_privacy_policy_content(
				esc_html__( '2gunta Recruitment', '2gunta-recruitment' ),
				$this->get_privacy_policy_text()
			);
		}
	}

	/**
	 * Get privacy policy content.
	 *
	 * @return string
	 */
	private function get_privacy_policy_text() {
		return esc_html__( '
When you submit a job application through our platform, we collect the following personal information:
- Name
- Email address
- Phone number
- Location
- Years of experience
- Resume/CV file
- Cover letter

This information is used to process your application and contact you regarding job opportunities. We keep your data secure and only share it with relevant hiring team members.

You have the right to:
- Access your personal data
- Request deletion of your data
- Opt-out of future communications

For data requests, please contact: ', '2gunta-recruitment' ) . get_option( 'admin_email' );
	}

	/**
	 * Export candidate data for GDPR compliance.
	 *
	 * @param string $email_address Candidate email.
	 * @return array
	 */
	public static function export_candidate_data( $email_address ) {
		global $wpdb;

		$candidate = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpc_candidates WHERE email = %s",
				$email_address
			)
		);

		if ( ! $candidate ) {
			return array();
		}

		$applications = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpc_applications WHERE candidate_id = %d",
				$candidate->id
			)
		);

		return array(
			'candidate' => $candidate,
			'applications' => $applications,
		);
	}

	/**
	 * Delete candidate data for GDPR compliance.
	 *
	 * @param string $email_address Candidate email.
	 */
	public static function delete_candidate_data( $email_address ) {
		global $wpdb;

		$candidate = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wpc_candidates WHERE email = %s",
				$email_address
			)
		);

		if ( ! $candidate ) {
			return;
		}

		// Delete applications.
		$wpdb->delete(
			$wpdb->prefix . 'wpc_applications',
			array( 'candidate_id' => $candidate->id ),
			array( '%d' )
		);

		// Delete candidate.
		$wpdb->delete(
			$wpdb->prefix . 'wpc_candidates',
			array( 'id' => $candidate->id ),
			array( '%d' )
		);
	}
}

new Privacy();
