<?php
/**
 * API Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * REST API endpoints.
 */
class API {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register REST API routes.
	 */
	public function register_routes() {
		register_rest_route(
			'2gunta-recruitment/v1',
			'/jobs',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_jobs' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'2gunta-recruitment/v1',
			'/jobs/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_job' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'2gunta-recruitment/v1',
			'/apply',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'submit_application' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			'2gunta-recruitment/v1',
			'/candidates',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_candidates' ),
				'permission_callback' => 'current_user_can',
			)
		);
	}

	/**
	 * Get jobs.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function get_jobs( $request ) {
		$args = array(
			'post_type'      => '2gunta_job',
			'posts_per_page' => $request->get_param( 'per_page' ) ?? 10,
			'paged'          => $request->get_param( 'page' ) ?? 1,
			'post_status'    => 'publish',
		);

		$jobs = new \WP_Query( $args );

		$data = array();
		if ( $jobs->have_posts() ) {
			while ( $jobs->have_posts() ) {
				$jobs->the_post();
				$data[] = array(
					'id'       => get_the_ID(),
					'title'    => get_the_title(),
					'location' => get_post_meta( get_the_ID(), '_job_location', true ),
					'salary'   => get_post_meta( get_the_ID(), '_job_salary', true ),
					'excerpt'  => get_the_excerpt(),
				);
			}
			wp_reset_postdata();
		}

		return new \WP_REST_Response( $data, 200 );
	}

	/**
	 * Get single job.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function get_job( $request ) {
		$job_id = $request->get_param( 'id' );
		$job    = get_post( $job_id );

		if ( ! $job || $job->post_type !== '2gunta_job' ) {
			return new \WP_REST_Response( array( 'error' => 'Job not found' ), 404 );
		}

		$data = array(
			'id'       => $job->ID,
			'title'    => $job->post_title,
			'content'  => $job->post_content,
			'location' => get_post_meta( $job->ID, '_job_location', true ),
			'salary'   => get_post_meta( $job->ID, '_job_salary', true ),
		);

		return new \WP_REST_Response( $data, 200 );
	}

	/**
	 * Submit application via API.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function submit_application( $request ) {
		// Validate nonce or API key.
		$params = $request->get_json_params();

		global $wpdb;

		// Create candidate.
		$candidate_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}wpc_candidates WHERE email = %s",
				$params['email']
			)
		);

		if ( ! $candidate_id ) {
			$wpdb->insert(
				$wpdb->prefix . 'wpc_candidates',
				array(
					'first_name' => $params['first_name'],
					'last_name'  => $params['last_name'],
					'email'      => $params['email'],
					'phone'      => $params['phone'] ?? '',
				),
				array( '%s', '%s', '%s', '%s' )
			);
			$candidate_id = $wpdb->insert_id;
		}

		// Create application.
		$wpdb->insert(
			$wpdb->prefix . 'wpc_applications',
			array(
				'job_id'       => $params['job_id'],
				'candidate_id' => $candidate_id,
				'status'       => 'new',
			),
			array( '%d', '%d', '%s' )
		);

		return new \WP_REST_Response( array( 'success' => true, 'message' => 'Application submitted' ), 201 );
	}

	/**
	 * Get candidates.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function get_candidates( $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_REST_Response( array( 'error' => 'Unauthorized' ), 403 );
		}

		global $wpdb;

		$candidates = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}wpc_candidates ORDER BY created_at DESC LIMIT 100"
		);

		return new \WP_REST_Response( $candidates, 200 );
	}
}

new API();
