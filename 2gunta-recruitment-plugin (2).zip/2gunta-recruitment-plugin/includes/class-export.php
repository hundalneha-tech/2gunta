<?php
/**
 * Export Class
 *
 * @package 2Gunta_Recruitment
 */

namespace TwoGunta_Recruitment;

/**
 * Data export functionality.
 */
class Export {

	/**
	 * Export candidates to CSV.
	 */
	public static function export_candidates_csv() {
		global $wpdb;

		$candidates = $wpdb->get_results(
			"SELECT id, first_name, last_name, email, phone, location, experience_years, created_at FROM {$wpdb->prefix}wpc_candidates ORDER BY created_at DESC"
		);

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=candidates_' . date( 'Y-m-d' ) . '.csv' );

		$fp = fopen( 'php://output', 'w' );
		fputcsv( $fp, array( 'ID', 'First Name', 'Last Name', 'Email', 'Phone', 'Location', 'Experience (Years)', 'Date' ) );

		foreach ( $candidates as $candidate ) {
			fputcsv( $fp, array(
				$candidate->id,
				$candidate->first_name,
				$candidate->last_name,
				$candidate->email,
				$candidate->phone,
				$candidate->location,
				$candidate->experience_years,
				$candidate->created_at,
			) );
		}

		fclose( $fp );
		exit;
	}

	/**
	 * Export applications to CSV.
	 *
	 * @param int $job_id Job ID.
	 */
	public static function export_applications_csv( $job_id ) {
		global $wpdb;

		$applications = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.*, c.first_name, c.last_name, c.email, p.post_title FROM {$wpdb->prefix}wpc_applications a
				LEFT JOIN {$wpdb->prefix}wpc_candidates c ON a.candidate_id = c.id
				LEFT JOIN $wpdb->posts p ON a.job_id = p.ID
				WHERE a.job_id = %d
				ORDER BY a.created_at DESC",
				$job_id
			)
		);

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=applications_' . $job_id . '_' . date( 'Y-m-d' ) . '.csv' );

		$fp = fopen( 'php://output', 'w' );
		fputcsv( $fp, array( 'ID', 'Candidate', 'Email', 'Job', 'Status', 'Date' ) );

		foreach ( $applications as $app ) {
			fputcsv( $fp, array(
				$app->id,
				$app->first_name . ' ' . $app->last_name,
				$app->email,
				$app->post_title,
				$app->status,
				$app->created_at,
			) );
		}

		fclose( $fp );
		exit;
	}
}
