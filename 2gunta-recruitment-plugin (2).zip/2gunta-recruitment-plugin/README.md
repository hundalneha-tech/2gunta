# 2gunta Recruitment ATS - WordPress Plugin

A complete, production-ready recruitment and applicant tracking system (ATS) for WordPress. Allows organizations to manage jobs, accept applications, track candidates, and streamline the hiring process.

## Features

### Core Features (MVP)
- ✅ **Job Management**: Create, edit, and publish job listings
- ✅ **Career Page**: Display all jobs with search and filter capabilities
- ✅ **Application Form**: Candidates can submit applications with resume upload
- ✅ **Candidate Dashboard**: View and manage all candidates and applications
- ✅ **Application Pipeline**: Move candidates through stages (New → Interview → Offer → Hired)
- ✅ **Email Notifications**: Automatic emails for applications, interview invites, rejections
- ✅ **CSV Export**: Export candidates and applications to CSV
- ✅ **GDPR Compliance**: Data export and deletion requests
- ✅ **REST API**: Access jobs and submit applications via API
- ✅ **Responsive Design**: Works on desktop, tablet, and mobile

### Advanced Features
- Candidate profile management
- Application status tracking with activity logs
- Email templates for standardized communication
- File upload handling (PDF, DOC, DOCX)
- Admin dashboard with statistics
- Candidate rating and scoring system
- Notes and internal comments
- Multi-language support

## Installation

### Prerequisites
- WordPress 5.0 or higher
- PHP 7.4 or higher
- MySQL 5.5.5 or higher

### Steps

1. **Upload Plugin**
   - Download the plugin folder
   - Upload to `/wp-content/plugins/2gunta-recruitment/`
   - Or use WordPress admin: Plugins → Add New → Upload Plugin

2. **Activate Plugin**
   - Go to WordPress admin: Plugins
   - Find "2gunta Recruitment ATS"
   - Click "Activate"

3. **Initial Setup**
   - The plugin automatically creates required database tables
   - Custom post types are registered
   - Navigation menus are automatically added

4. **Configure Settings**
   - Go to Jobs → Settings
   - Configure career page title
   - Set email addresses for notifications
   - Upload file size and type restrictions

## Usage

### Creating Jobs

1. Go to **Jobs** in WordPress admin
2. Click **Add New Job**
3. Enter job title and description
4. In the **Job Details** box, add:
   - Location
   - Salary range
   - Job type (Full-time, Part-time, etc.)
5. Select job category and type
6. Click **Publish**

### Managing Applications

1. Go to **Jobs → Applications** (or **Candidates**)
2. View all applications and candidates
3. Click on a candidate to view details
4. Click **Update Status** to change application status
5. Use **Send Email** to contact candidate with pre-written templates

### Career Page

Add the careers shortcode to any page:

```
[2gunta_careers]
```

This displays:
- All published jobs
- Search bar to filter by title/location
- Job detail cards with apply button

### Job Detail Page

Automatically generated when you publish a job. Includes:
- Full job description
- Application form
- Share buttons (optional)

### Application Form

Add the form to any page or job detail:

```
[2gunta_application_form]
```

Or it automatically appears on job detail pages.

## Shortcodes

### Career Page
```
[2gunta_careers]
```
Displays list of all jobs with search functionality.

### Application Form
```
[2gunta_application_form]
```
Displays job application form on singular job pages.

## REST API Endpoints

### Get All Jobs
```
GET /wp-json/2gunta-recruitment/v1/jobs
```

Query parameters:
- `per_page` (default: 10)
- `page` (default: 1)

### Get Single Job
```
GET /wp-json/2gunta-recruitment/v1/jobs/{id}
```

### Submit Application
```
POST /wp-json/2gunta-recruitment/v1/apply
```

Body:
```json
{
  "job_id": 123,
  "first_name": "John",
  "last_name": "Doe",
  "email": "john@example.com",
  "phone": "+1234567890"
}
```

### Get Candidates (Admin only)
```
GET /wp-json/2gunta-recruitment/v1/candidates
```

Requires admin authentication.

## Database Schema

### wp_wpc_candidates
- id (Primary Key)
- user_id
- first_name
- last_name
- email (Unique)
- phone
- skills
- experience_years
- location
- portfolio_url
- tags
- notes
- rating
- created_at
- updated_at

### wp_wpc_applications
- id (Primary Key)
- job_id (Foreign Key)
- candidate_id (Foreign Key)
- resume_url
- cover_letter
- status (new, phone-screen, interview, offer, hired, rejected)
- stage
- rating
- notes
- created_at
- updated_at

### wp_wpc_activity_log
- id (Primary Key)
- user_id
- candidate_id
- application_id
- action
- details
- created_at

## Settings

Access settings at **Jobs → Settings**:

| Setting | Description | Default |
|---------|-------------|---------|
| Career Page Title | Title shown on careers page | "Careers at 2gunta" |
| Recruitment Email | Email for notifications | Admin email |
| Items Per Page | Jobs per page on careers page | 10 |
| Max File Size | Maximum resume file size (bytes) | 5242880 (5MB) |
| Allowed File Types | Allowed resume formats | pdf, doc, docx |
| Enable GDPR | Enable data privacy features | Yes |

## Admin Dashboard

The plugin adds an admin dashboard showing:
- Active jobs count
- Total applications count
- Unique candidates count
- Recent applications list
- Quick actions for each application

Access at **Jobs → Dashboard**

## Email Templates

Pre-configured email templates for:

- **Application Received**: Sent to candidate after submission
- **Interview Invite**: Invite candidate for interview
- **Job Offer**: Send job offer
- **Rejection**: Decline candidate application
- **Admin Notification**: Notify admin of new application

Customize at **Jobs → Settings → Email Templates**

## File Upload Security

- Uploads are stored in `/wp-content/uploads/resumes/`
- Supported formats: PDF, DOC, DOCX (configurable)
- File size limit: 5MB (configurable)
- Files are validated before upload
- Random filenames prevent direct access

## Security Features

- Nonce verification on all forms
- Input sanitization on all data
- SQL injection prevention via $wpdb prepared statements
- XSS protection via wp_kses functions
- User capability checking on admin pages
- Rate limiting on application forms (via reCAPTCHA)

## GDPR Compliance

### Candidates' Rights

1. **Data Access**: Candidates can request their data
2. **Data Export**: Export personal data in CSV format
3. **Data Deletion**: Request account and data deletion

### Privacy Policy

The plugin adds sections to the WordPress privacy policy page describing:
- What data is collected
- How it's used
- How long it's retained
- How to request deletion

## Troubleshooting

### Applications Not Submitting
- Check browser console for errors (F12)
- Verify file size doesn't exceed limit
- Check file format (PDF, DOC, DOCX only)
- Clear browser cache

### Emails Not Sending
- Verify SMTP configuration in WordPress
- Check "Recruitment Email" setting
- Look in WordPress debug log: `/wp-content/debug.log`
- Test with `wp_mail()` by installing mail testing plugin

### Jobs Not Appearing on Career Page
- Verify job is published (not draft)
- Check job has title and description
- Wait for caching plugin to clear if using cache

### Database Error on Activation
- Verify PHP version is 7.4+
- Check database user has CREATE TABLE permissions
- Review WordPress debug log
- Try deactivating/reactivating plugin

## Custom Modifications

### Register Additional Job Meta Fields

```php
add_filter( '2gunta_recruitment_job_meta_fields', function( $fields ) {
    $fields['custom_field'] = 'Custom Field Label';
    return $fields;
});
```

### Modify Email Templates

```php
add_filter( '2gunta_recruitment_email_template_content', function( $content, $template ) {
    if ( $template === 'interview_invite' ) {
        $content = 'Custom interview invite message...';
    }
    return $content;
}, 10, 2 );
```

### Extend Application Form Fields

```php
add_action( '2gunta_recruitment_application_form_fields', function() {
    ?>
    <div class="form-group">
        <label>Custom Field</label>
        <input type="text" name="custom_field" class="form-control" />
    </div>
    <?php
});
```

## Development

### File Structure
```
2gunta-recruitment/
├── 2gunta-recruitment.php          # Main plugin file
├── includes/
│   ├── class-2gunta-recruitment.php # Main class
│   ├── class-activator.php         # Activation logic
│   ├── class-deactivator.php       # Deactivation logic
│   ├── class-posts.php             # Custom post types
│   ├── class-admin.php             # Admin functionality
│   ├── class-public.php            # Frontend functionality
│   ├── class-email.php             # Email handling
│   ├── class-api.php               # REST API
│   ├── class-database.php          # Database queries
│   ├── class-settings.php          # Plugin settings
│   ├── class-export.php            # CSV export
│   └── class-privacy.php           # GDPR compliance
├── assets/
│   ├── css/
│   │   ├── public.css              # Frontend styles
│   │   └── admin.css               # Admin styles
│   └── js/
│       ├── public.js               # Frontend scripts
│       └── admin.js                # Admin scripts
└── README.md                        # This file
```

### Code Standards
- Follows [WordPress Coding Standards](https://developer.wordpress.org/coding-standards/)
- Uses namespaces for classes
- Proper use of hooks and filters
- Security: sanitization, validation, nonce verification
- Accessibility: WCAG 2.1 AA compliant (aim)
- Internationalization: All strings wrapped with `__()` and `esc_html__()`

## Future Enhancements

- [ ] Job syndication to Indeed, LinkedIn, Monster
- [ ] Resume parsing API integration (Rchilli, Sovren)
- [ ] Employer portal for job posting
- [ ] Kanban drag-drop interface for pipeline
- [ ] Advanced analytics and reporting
- [ ] Interview scheduling integration
- [ ] Email template builder UI
- [ ] Bulk candidate actions
- [ ] Advanced search and filtering
- [ ] Candidate tags and custom fields

## Support

For issues, questions, or feature requests:
1. Check the Troubleshooting section above
2. Review [WordPress Plugin Documentation](https://developer.wordpress.org/plugins/)
3. Contact: support@2gunta.com

## License

This plugin is released under the GPL v2 or later. See LICENSE file for details.

## Changelog

### Version 1.0.0 (Initial Release)
- Initial release with MVP features
- Job creation and management
- Application submission and tracking
- Candidate dashboard
- Email notifications
- GDPR compliance
- REST API

---

**2gunta Recruitment ATS** - Making hiring easier, faster, and better.
