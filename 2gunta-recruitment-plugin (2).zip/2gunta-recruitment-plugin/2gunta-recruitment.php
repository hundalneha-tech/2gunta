<?php
/**
 * Plugin Name: 2gunta Recruitment ATS
 * Description: Complete recruitment and ATS system for job posting, applications, and candidate management
 * Version: 1.0.0
 * Author: 2gunta Solutions
 * Author URI: https://www.2gunta.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: 2gunta-recruitment
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 *
 * @package 2Gunta_Recruitment
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants.
define( 'GUNTA_RECRUITMENT_VERSION', '1.0.0' );
define( 'GUNTA_RECRUITMENT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GUNTA_RECRUITMENT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'GUNTA_RECRUITMENT_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Load main class.
require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-2gunta-recruitment.php' );

/**
 * Initialize the main plugin class.
 */
function gunta_recruitment_init() {
	return \TwoGunta_Recruitment\Main::get_instance();
}
add_action( 'plugins_loaded', 'gunta_recruitment_init' );

/**
 * Activation hook.
 */
function gunta_recruitment_activate() {
	require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-database.php' );
	require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-posts.php' );
	require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-activator.php' );
	\TwoGunta_Recruitment\Activator::activate();
}
register_activation_hook( __FILE__, 'gunta_recruitment_activate' );

/**
 * Deactivation hook.
 */
function gunta_recruitment_deactivate() {
	require_once( GUNTA_RECRUITMENT_PLUGIN_DIR . 'includes/class-deactivator.php' );
	\TwoGunta_Recruitment\Deactivator::deactivate();
}
register_deactivation_hook( __FILE__, 'gunta_recruitment_deactivate' );
