# 2gunta Recruitment - DEPLOYMENT EXECUTION CHECKLIST
## Ready-to-Print Deployment Walkthrough (February 22, 2026)

---

## 📋 PRE-DEPLOYMENT VERIFICATION (Do This First!)

**Date:** ________________  
**Deployed by:** ________________  
**Target Server:** 2gunta.com  
**Plugin Version:** 1.0.0  

### Environment Verification
- [ ] **WordPress Version:** __________ (Must be 5.0+)
- [ ] **PHP Version:** __________ (Must be 7.4+)  
- [ ] **MySQL Version:** __________ (Must be 5.5.5+)
- [ ] **SSL Active:** Yes / No
- [ ] **Backup Created:** Yes / No  
  - Backup Location: __________________________
- [ ] **Admin Access Verified:** Yes / No

### Credentials Ready
- [ ] **Google Maps API Key:** AIzaSyCZLboqyLKt1dVYCqnjPNKA-3SLHGUpefo ✓
- [ ] **Google Analytics ID:** G-B66X9RBN8T ✓
- [ ] **reCAPTCHA Site Key:** 6LcKJ3QsAAAAAFygnbt0gY1eO9rqv5BGwD8VVuJX ✓
- [ ] **reCAPTCHA Secret Key:** 6LcKJ3QsAAAAAMzFJc9cs57kf05BSBb8acynm1yC ✓
- [ ] **SMTP Email Server:** __________________________
- [ ] **SMTP Username:** __________________________
- [ ] **SMTP Password:** ✓ (stored securely)

---

## 🚀 DEPLOYMENT PHASE

### Step 1: FTP/SFTP Connection
- [ ] Connected to: 2gunta.com
- [ ] Username: __________________________
- [ ] Current Directory: /wp-content/plugins/
- [ ] Connection Type: FTP / SFTP / SSH

### Step 2: Upload Plugin Files
- [ ] Source: C:\Users\woof\2gunta-recruitment-plugin\
- [ ] Destination: /wp-content/plugins/2gunta-recruitment-plugin/
- [ ] Files Uploaded: __________ files
- [ ] Upload Status: ✓ Complete
- [ ] Upload Time: Started __________ Ended __________

### Step 3: Set File Permissions
```bash
# Run these commands if uploading via SSH:

cd /wp-content/plugins/2gunta-recruitment-plugin/
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;
ls -la | head
```

- [ ] Directories: 755 ✓
- [ ] Files: 644 ✓
- [ ] Ownership: www-data ✓

### Step 4: Verify Upload
```bash
# SSH verification
ls -la /wp-content/plugins/2gunta-recruitment-plugin/ | grep -E "2gunta-recruitment.php|includes|assets|admin"
```

Files visible:
- [ ] 2gunta-recruitment.php ✓
- [ ] includes/ ✓
- [ ] assets/ ✓
- [ ] admin/ ✓
- [ ] public/ ✓
- [ ] templates/ ✓

---

## ⚡ ACTIVATION PHASE

### Step 1: Access WordPress Admin
- [ ] URL: https://2gunta.com/wp-admin/
- [ ] Logged In: Yes / No
- [ ] Admin Role: Verified ✓

### Step 2: Activate Plugin
- [ ] Location: Plugins → All Plugins
- [ ] Found: "2gunta Recruitment ATS"
- [ ] Status: Inactive → Active
- [ ] Click: Activate
- [ ] Timestamp: __________

### Step 3: Verify Activation Success
- [ ] No error messages
- [ ] Plugin shows as "Active"
- [ ] New menu "Jobs" visible in sidebar
- [ ] Database tables created:
  - [ ] wp_wpc_jobs
  - [ ] wp_wpc_candidates
  - [ ] wp_wpc_applications
  - [ ] wp_wpc_activity_log

### Step 4: Check for Errors
```bash
# SSH command to check errors
tail -50 /var/log/php-errors.log | grep "2gunta"
```

- [ ] No errors found / Errors: __________________________

---

## 🔧 CONFIGURATION PHASE

### Step 1: Configure Google APIs
- [ ] Go to: Jobs → Settings → Google APIs Configuration Tab
- [ ] Paste Google Maps API Key
  - [ ] Value: AIzaSyCZLboqyLKt1dVYCqnjPNKA-3SLHGUpefo ✓
- [ ] Paste Google Analytics ID
  - [ ] Value: G-B66X9RBN8T ✓
- [ ] Paste reCAPTCHA Site Key
  - [ ] Value: 6LcKJ3QsAAAAAFygnbt0gY1eO9rqv5BGwD8VVuJX ✓
- [ ] Paste reCAPTCHA Secret Key
  - [ ] Value: 6LcKJ3QsAAAAAMzFJc9cs57kf05BSBb8acynm1yC ✓
- [ ] Enable Google Maps: ✓
- [ ] Enable Analytics: ✓
- [ ] Enable reCAPTCHA: ✓
- [ ] Click: Save Changes
- [ ] Confirmation: "Settings saved." ✓

### Step 2: Configure Email
- [ ] Go to: Jobs → Settings → Email Notifications Tab
- [ ] From Email: noreply@2gunta.com
- [ ] From Name: 2gunta Recruitment
- [ ] Admin Email: admin@2gunta.com
- [ ] Enable HTML: ✓
- [ ] Click: Save Changes
- [ ] Send Test Email to: test@example.com
  - [ ] Test Email Received: Yes / No
  - [ ] Timestamp: __________

### Step 3: Create Career Page
- [ ] Go to: Pages → Add New
- [ ] Title: Careers
- [ ] Content: [2gunta_careers]
- [ ] Publish
- [ ] URL: __________________________

### Step 4: Create Application Form Page
- [ ] Go to: Pages → Add New
- [ ] Title: Apply for a Job
- [ ] Content: [2gunta_application_form]
- [ ] Publish
- [ ] URL: __________________________

### Step 5: Link Pages in Settings
- [ ] Go to: Jobs → Settings → General Tab
- [ ] Career Page URL: __________________________
- [ ] Application Form URL: __________________________
- [ ] Click: Save Changes

---

## ✅ TESTING PHASE

### Test 1: Career Page Display
- [ ] Visit: https://2gunta.com/[careers-url]/
- [ ] Page loads: Yes / No
- [ ] Shows "Careers" heading: Yes / No
- [ ] Job listings visible: Yes / No
- [ ] Search box present: Yes / No

**Issues Found:** __________________________

### Test 2: Job Detail Page
- [ ] Click on a job: Yes / No
- [ ] Job details load: Yes / No
- [ ] Google Map displays: Yes / No
  - [ ] Can pan map: Yes / No
  - [ ] Can zoom map: Yes / No
  - [ ] Marker visible: Yes / No
- [ ] "Apply Now" button visible: Yes / No

**Issues Found:** __________________________

### Test 3: Application Form
- [ ] Click "Apply Now": Yes / No
- [ ] Form page loads: Yes / No
- [ ] All form fields visible: Yes / No
- [ ] File upload works: Yes / No
- [ ] Fill out form completely: Yes / No
- [ ] Check privacy checkbox: Yes / No
- [ ] Click Submit: Yes / No

**Form Submission Time:** __________

### Test 4: Form Submission Response
- [ ] "Verifying..." state shows: Yes / No
- [ ] Success message appears: Yes / No
- [ ] Form clears after submit: Yes / No
- [ ] Success email received: Yes / No
  - [ ] Time received: __________
  - [ ] Email address: __________________________

**Issues Found:** __________________________

### Test 5: Google Maps API
- [ ] Open DevTools → Network tab
- [ ] Reload job detail page
- [ ] Search for: "maps.googleapis"
- [ ] Request found: Yes / No
- [ ] Response 200: Yes / No

**Issues Found:** __________________________

### Test 6: reCAPTCHA
- [ ] Open DevTools → Network tab
- [ ] Reload application form
- [ ] Search for: "recaptcha"
- [ ] Script loads: Yes / No
- [ ] Submit form
- [ ] Siteverify request sent: Yes / No

**Issues Found:** __________________________

### Test 7: Google Analytics
- [ ] Open DevTools → Network tab
- [ ] Search for: "googletagmanager" or "gtag"
- [ ] Requests visible: Yes / No
- [ ] Visit multiple pages
- [ ] Multiple requests logged: Yes / No

**Note:** Check GA dashboard after 24 hours

**Issues Found:** __________________________

---

## 🎉 FINAL VERIFICATION

### All Tests Passed?
- [ ] **YES** - Deployment successful! Proceed to production monitoring.
- [ ] **NO** - Issues found. See "ROLLBACK" section below.

### Production Status
```
Date: __________
Time: __________
Status: LIVE ✓
Verified by: __________
```

---

## ⚠️ ISSUES ENCOUNTERED & RESOLUTIONS

| Issue | Cause | Resolution | Status |
|-------|-------|-----------|--------|
| | | | |
| | | | |
| | | | |

---

## 🔄 ROLLBACK PROCEDURE (If needed)

### Quick Disable
```bash
# Via SSH:
cd /wp-content/plugins/
mv 2gunta-recruitment-plugin 2gunta-recruitment-plugin-DISABLED
```

Then reload WordPress. Plugin will be inactive.

### Restore from Backup
```bash
# Restore database backup
mysql -u [user] -p [database] < backup_[date].sql

# Or:
# Use WordPress backup plugin to restore
```

### Rollback Initiated?
- [ ] Yes - Time: __________
- [ ] Reason: __________________________
- [ ] Backup Restored: Yes / No
- [ ] Verified: Site working as before

---

## 📊 DEPLOYMENT SUMMARY

**Status:** 
- [ ] ✅ SUCCESS - All systems operational
- [ ] ⚠️ PARTIAL - Some features working, issues logged
- [ ] ❌ FAILED - See rollback section

**Deployment Duration:** 
From __________ to __________ (Total: __________ minutes)

**Deployed Files:** __________ total

**Database Tables Created:** 4 tables ✓

**Configuration Verified:**
- [ ] Google APIs: 4/4 configured ✓
- [ ] Email Notifications: Tested ✓
- [ ] Career Page: Live ✓
- [ ] Application Form: Live ✓

**Next Steps:**
1. Monitor error logs for 24 hours
2. Check Google Analytics dashboard tomorrow
3. Schedule follow-up testing in 1 week
4. Document any issues for future reference

---

**Deployment Completed By:**  
Name: __________________________  
Date: __________________________  
Signature: __________________________

**Approved By:**  
Name: __________________________  
Date: __________________________  
Signature: __________________________

---

## 📞 Support Contacts

If issues arise during deployment:

1. **Technical Support:** [Your Support Email]
2. **Google APIs Issues:** [Google Support]
3. **WordPress Help:** [WordPress.org Support]
4. **Server Admin:** [Your Hosting Provider]

---

**Plugin Version:** 1.0.0  
**Deployment Date:** February 22, 2026  
**Target:** 2gunta.com WordPress Installation
