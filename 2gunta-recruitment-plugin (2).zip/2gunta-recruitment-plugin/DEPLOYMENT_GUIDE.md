# Complete Deployment & Google APIs Setup Guide

**2gunta Recruitment ATS - Production Deployment**  
**Date:** February 2026

---

## 📋 Table of Contents

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Google APIs Setup](#google-apis-setup)
3. [Plugin Deployment Steps](#plugin-deployment-steps)
4. [Post-Deployment Configuration](#post-deployment-configuration)
5. [Testing Verification](#testing-verification)
6. [Go-Live Checklist](#go-live-checklist)

---

## ✅ Pre-Deployment Checklist

Before deploying to production, verify:

- [ ] 2gunta.com WordPress installation running (latest version)
- [ ] PHP 7.4 or higher installed
- [ ] MySQL 5.5.5 or higher available
- [ ] SSH/FTP access to server
- [ ] Database backup completed
- [ ] SSL/HTTPS enabled on domain
- [ ] Email sending configured (SMTP or sendmail)
- [ ] File upload directory writable (`/wp-content/uploads/`)
- [ ] Backup of current `/wp-content/` folder taken
- [ ] Google Console account access ready

---

## 🔑 Google APIs Setup

### Step 1: Create Google Cloud Project

1. Go to **Google Cloud Console** (https://console.cloud.google.com/)
2. Click **Select a Project** → **NEW PROJECT**
3. Enter project name: `2gunta-recruitment`
4. Click **CREATE**
5. Wait for project to be created (1-2 minutes)

### Step 2: Enable Required APIs

In your new project:

#### A. Enable reCAPTCHA API
1. Go to **APIs & Services** → **Library**
2. Search for "reCAPTCHA"
3. Click **reCAPTCHA Enterprise API** → **ENABLE**

#### B. Enable Maps JavaScript API
1. Search for "Maps JavaScript"
2. Click **Maps JavaScript API** → **ENABLE**

#### C. Enable Analytics API (Optional)
1. Search for "Google Analytics"
2. Click **Google Analytics API** → **ENABLE**

### Step 3: Create API Keys & Credentials

#### reCAPTCHA Keys

1. Go to **APIs & Services** → **Credentials**
2. Click **CREATE CREDENTIALS** → **API Key**
3. Restrict to reCAPTCHA Enterprise API
4. **Copy this key** - you'll need it

Now go to [reCAPTCHA Admin Console](https://www.google.com/recaptcha/admin)

1. Click **Create** button at top left
2. Enter:
   - **Label:** `2gunta Recruitment`
   - **reCAPTCHA type:** Select v3 (recommended for forms)
   - **Domain:** `2gunta.com`
3. Click **CREATE**
4. Copy:
   - **Site Key** - for frontend
   - **Secret Key** - for backend/WordPress

#### Google Maps API Key

1. Back in Cloud Console → **APIs & Services** → **Credentials**
2. Click **CREATE CREDENTIALS** → **API Key**
3. Restrict to:
   - **Maps JavaScript API**
   - **Maps Static API**
4. **Copy this key**

#### Google Analytics (Optional - for tracking)

1. Set up at [Google Analytics](https://analytics.google.com/)
2. Create new property for `2gunta.com`
3. Get your **Measurement ID** (format: G-XXXXXXXXXX)

### Step 4: Prepare API Credentials Sheet

Create a file with all keys (keep this secure!):

```
RECAPTCHA Setup:
  Site Key (Frontend):     [YOUR_RECAPTCHA_SITE_KEY]
  Secret Key (Backend):    [YOUR_RECAPTCHA_SECRET_KEY]
  
GOOGLE MAPS Setup:
  Maps API Key:            [YOUR_MAPS_API_KEY]
  
GOOGLE ANALYTICS Setup:
  Measurement ID:          [YOUR_ANALYTICS_ID]
```

**IMPORTANT:** Store these securely. Never commit to GitHub!

---

## 🚀 Plugin Deployment Steps

### Step 1: Prepare Plugin Files

```bash
# On your local machine
cd C:\Users\woof\2gunta-recruitment-plugin

# Verify all files are present
dir /s

# Should see:
# - 2gunta-recruitment.php
# - includes/ (12 PHP files)
# - assets/ (CSS + JS)
# - All documentation files
```

### Step 2: Upload to Server

**Option A: Using FTP/SFTP (Recommended)**

1. Open FileZilla or your FTP client
2. Connect to `2gunta.com` with your credentials
3. Navigate to: `/public_html/wordpress/wp-content/plugins/`
4. Drag and drop `2gunta-recruitment` folder
5. Wait for upload to complete (should take ~30 seconds)
6. Verify all files uploaded (especially check `includes/` folder)

**Option B: Using WordPress Admin**

1. Login to `https://2gunta.com/wordpress/wp-admin/`
2. Go to **Plugins** → **Add New** → **Upload Plugin**
3. Select `2gunta-recruitment.zip` file
4. Click **Install Now**
5. WordPress will extract and prepare the plugin

**Option C: Using SSH (If available)**

```bash
# SSH into your server
ssh user@2gunta.com

# Navigate to plugins directory
cd public_html/wordpress/wp-content/plugins/

# Copy plugin from local backup or GitHub
cp -r /backup/2gunta-recruitment ./

# Set correct permissions
chmod -R 755 2gunta-recruitment/
chmod -R 644 2gunta-recruitment/includes/*.php
```

### Step 3: Activate Plugin

1. Login to WordPress: `https://2gunta.com/wordpress/wp-admin/`
2. Go to **Plugins**
3. Find **2gunta Recruitment ATS**
4. Click **Activate**
5. You should see: ✓ "Plugin activated successfully"

### Step 4: Verify Installation

Check that:

1. **Database tables created:**
   - **Tools** → **Site Health** → **Database**
   - Look for: `wp_wpc_candidates`, `wp_wpc_applications`, `wp_wpc_activity_log`

2. **Admin menu visible:**
   - **Jobs** menu item should appear in WordPress sidebar
   - Sub-items: Dashboard, Add New, Applications, Candidates, Settings

3. **Folder created:**
   - `/public_html/wordpress/wp-content/uploads/resumes/` should exist

---

## ⚙️ Post-Deployment Configuration

### Step 1: Basic Settings Configuration

1. Go to **Jobs** → **Settings** in WordPress admin
2. Configure:

| Setting | Value | Notes |
|---------|-------|-------|
| Career Page Title | "Join Our Team" | Displayed on careers page |
| Recruitment Email | your-email@2gunta.com | Where notifications go |
| Items Per Page | 10 | Jobs per page in listings |
| Max File Size | 5242880 (5MB) | Resume upload limit |
| Allowed File Types | pdf,doc,docx | Resume formats |
| Enable GDPR | ✓ Checked | Required for compliance |

3. Click **Save Changes**

### Step 2: Google APIs Integration

In **Jobs** → **Settings** → **API Configuration** section:

1. **reCAPTCHA Settings:**
   - Site Key: [paste your reCAPTCHA site key]
   - Secret Key: [paste your reCAPTCHA secret key]
   - Enable reCAPTCHA: ✓ Checked

2. **Google Maps Settings:**
   - Maps API Key: [paste your Google Maps API key]
   - Enable Maps: ✓ Checked
   - Default Map Center: 40.7128, -74.0060 (New York)

3. **Google Analytics Settings:**
   - Measurement ID: [paste your Analytics ID, e.g., G-XXXXXXXXXX]
   - Enable Analytics: ✓ Checked

4. Click **Save Changes**

### Step 3: Create Career Page

1. Go to **Pages** → **Add New**
2. Enter:
   - **Title:** "Careers" or "Join Our Team"
   - **Content:** Add this shortcode:
     ```
     [2gunta_careers]
     ```
3. Scroll down to **Page Attributes**:
   - Parent: (none)
   - Template: Default
4. Click **Publish**
5. Note the URL (e.g., `https://2gunta.com/careers/`)

### Step 4: Add to Menu (Optional but Recommended)

1. Go to **Appearance** → **Menus**
2. Edit your main menu
3. Click **Add items** → **Pages**
4. Select "Careers" page
5. Drag to desired position
6. Click **Save Menu**

### Step 5: Configure Email

#### Verify WordPress Can Send Email

1. Go to **Tools** → **Site Health**
2. Look for "Email delivery" status
3. If "Problem detected", install **WP Mail SMTP** plugin:
   - **Plugins** → **Add New**
   - Search: "WP Mail SMTP"
   - Click **Install Now** → **Activate**
   - Go to **Settings** → **WP Mail SMTP**
   - Configure SMTP:
     - Mailer: Gmail (or your email service)
     - Gmail Account: your-email@2gunta.com
     - Follow authentication steps
   - Test email sending

### Step 6: Create Sample Jobs (Testing)

1. Go to **Jobs** → **Add New Job**
2. Fill in:
   - **Title:** "Senior PHP Developer"
   - **Content:** Paste sample job description
   - **Job Details:**
     - Location: "New York, NY"
     - Salary Min: 80000
     - Salary Max: 120000
     - Job Type: "Full-time"
   - **Category:** Engineering (create if needed)
3. Click **Publish**
4. Repeat for 2-3 more sample jobs

---

## 🧪 Testing Verification

### Pre-Go-Live Tests

#### 1. Career Page Display
```
✓ Test Step:
  1. Visit https://2gunta.com/careers/
  2. Verify career page loads with job listings
  3. Check search/filter functionality works
  4. Verify jobs display with correct information
```

#### 2. Job Detail Page
```
✓ Test Step:
  1. Click on a job from career page
  2. Verify job detail page loads completely
  3. Check all information displays correctly
  4. Click "Apply Now" button
```

#### 3. Application Form
```
✓ Test Step:
  1. Fill out test application:
     - First Name: "Test"
     - Last Name: "Applicant"
     - Email: your-test-email@domain.com
     - Phone: (555) 123-4567
     - Location: "Test City"
     - Upload test resume (PDF)
  2. Check reCAPTCHA loads and validates
  3. Check Google Maps loads (if enabled)
  4. Click "Submit Application"
  5. Verify success message appears
```

#### 4. Email Notifications
```
✓ Test Step:
  1. Check test email inbox
  2. Verify application confirmation email received
  3. Check recruitment email (from settings)
  4. Verify admin notification email received
  5. Check both emails have correct content
```

#### 5. Admin Dashboard
```
✓ Test Step:
  1. Go to https://2gunta.com/wordpress/wp-admin/
  2. Click Jobs → Dashboard
  3. Verify statistics show counts
  4. Check recent applications list
  5. Click on test application
  6. Test "Update Status" button
  7. Try "Send Email" template option
```

#### 6. API Endpoints (Testing with curl)
```bash
# Test Jobs List Endpoint
curl "https://2gunta.com/wp-json/2gunta-recruitment/v1/jobs"

# Test Single Job
curl "https://2gunta.com/wp-json/2gunta-recruitment/v1/jobs/123"

# Test Application Submission
curl -X POST "https://2gunta.com/wp-json/2gunta-recruitment/v1/apply" \
  -H "Content-Type: application/json" \
  -d '{
    "job_id": 123,
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com",
    "phone": "+1-555-0100"
  }'
```

#### 7. Google Analytics Tracking
```
✓ Test Step:
  1. Open Chrome DevTools (F12)
  2. Go to Console tab
  3. Visit career page
  4. Look for: "[MOCK] Google Analytics - Career page viewed"
  5. Check Google Analytics dashboard after 24 hours
```

#### 8. Database Verification
```bash
# SSH into server and check database
mysql -u wordpress_user -p wordpress_db

# In MySQL:
SHOW TABLES LIKE 'wp_wpc%';

# Should see 3 tables:
# wp_wpc_candidates
# wp_wpc_applications  
# wp_wpc_activity_log

# Check record counts:
SELECT COUNT(*) FROM wp_wpc_candidates;
SELECT COUNT(*) FROM wp_wpc_applications;
```

---

## ✅ Go-Live Checklist

Before making the site public:

### Security
- [ ] SSL/HTTPS enabled and working
- [ ] WordPress updated to latest version
- [ ] All plugins updated
- [ ] Admin username changed from "admin"
- [ ] Strong passwords set
- [ ] Backup completed and tested
- [ ] Security plugin installed (Wordfence recommended)

### Functionality
- [ ] Career page displays correctly
- [ ] Application form works
- [ ] Emails send successfully
- [ ] Admin dashboard functional
- [ ] All sample jobs display
- [ ] Database tables created and populated
- [ ] File uploads working
- [ ] reCAPTCHA validates correctly

### Configuration
- [ ] All Google APIs configured
- [ ] Email notifications set up
- [ ] Privacy policy updated with recruitment info
- [ ] GDPR consent checkbox displays
- [ ] Analytics tracking enabled

### Analytics & Monitoring
- [ ] Google Analytics property created
- [ ] Error logging enabled
- [ ] Uptime monitoring configured
- [ ] Daily backups scheduled
- [ ] Email alerts set up

### Documentation & Support
- [ ] Documentation accessible to team
- [ ] Admin trained on dashboard
- [ ] Support email monitored
- [ ] FAQ or help page updated
- [ ] Contact form configured

---

## 🎯 Production Deployment Summary

### What Gets Deployed
```
✓ 12 PHP Classes (2048+ lines)
✓ 4 Frontend Assets (CSS + JS)
✓ Database schema (3 tables)
✓ REST API (4 endpoints)
✓ Admin interface
✓ Public career page
✓ Email system
✓ GDPR compliance
✓ All documentation
```

### What Stays on Local Dev
```
✗ Node modules / build files
✗ Development configs
✗ Test files
✗ Git history (.git/ folder)
```

### File Size
- Plugin total: ~500KB
- Database tables: Variable (grows with data)
- Recommended backup size: 10MB initial

---

## 🔒 Security After Deployment

### Daily Tasks
- Monitor email for new applications
- Review new candidates in dashboard
- Check error logs

### Weekly Tasks
- Backup database
- Review security scan results
- Update any plugins with available updates

### Monthly Tasks
- Analyze recruitment metrics
- Review candidate feedback
- Clean up old application data (optional)
- Test disaster recovery/restore

---

## 📞 Support & Troubleshooting

### Common Issues & Solutions

**Career page shows "[2gunta_careers]" text**
- Plugin not activated
- Solution: Go to Plugins and activate

**No emails sending**
- SMTP not configured
- Solution: Install WP Mail SMTP and configure

**API returns 404**
- Rewrite rules not flushed
- Solution: Go to Settings → Permalinks → Save

**File upload fails**
- Permissions issue
- Solution: `chmod 755 /wp-content/uploads/`

**reCAPTCHA not working**
- Keys not configured correctly
- Solution: Verify site/secret keys in settings

### Contact/Escalation
- Production issues: support@2gunta.com
- Plugin support: GitHub issues or documentation
- Google API issues: Google Cloud support

---

## 🎉 Success Indicators

You'll know deployment was successful when:

1. ✅ Career page is live at `2gunta.com/careers/`
2. ✅ First test application submitted successfully
3. ✅ Confirmation email received
4. ✅ Application visible in admin dashboard
5. ✅ Admin can update application status
6. ✅ Jobs searchable and filterable
7. ✅ Analytics tracking page views
8. ✅ reCAPTCHA protecting forms

---

## 📋 Deployment Completion Checklist

After completing all steps above, mark as complete:

- [ ] Google APIs created and configured
- [ ] Plugin uploaded to server
- [ ] Plugin activated in WordPress
- [ ] Database tables verified
- [ ] Settings configured
- [ ] Career page created
- [ ] Sample jobs created
- [ ] All tests passed
- [ ] Email verified working
- [ ] Go-live checklist completed
- [ ] Team notified
- [ ] Analytics tags implemented
- [ ] Backup completed
- [ ] Monitoring enabled

---

## 📞 Post-Deployment Support

**First 30 Days:**
- Daily monitoring of new applications
- Weekly performance review
- Feedback collection from users

**After 30 Days:**
- Monthly metrics review
- Quarterly feature enhancements
- Version updates as available

---

**Deployment Date:** _______________  
**Deployed By:** _______________  
**Verification Completed:** _______________  
**Go-Live Approved By:** _______________

---

**Next Phase:** Version 1.1 enhancements (resume parser, advanced analytics, job syndication)

Good luck with your deployment! 🚀
