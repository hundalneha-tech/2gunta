# REST API Reference

## Base URL
```
https://your-domain.com/wp-json/2gunta-recruitment/v1
```

## Authentication

### Public Endpoints
- GET `/jobs` - No authentication required
- GET `/jobs/{id}` - No authentication required
- POST `/apply` - No authentication required (but validated)

### Admin Endpoints
- GET `/candidates` - Requires WordPress admin authentication (manage_options capability)

### Authentication Methods
```
1. WordPress Session (Browser)
   - Automatically authenticated if logged in as admin
   
2. Application Passwords (See WordPress REST API)
   - Generate app password in user profile
   - Include in Authorization header: Bearer <token>
```

---

## Response Format

### Success Response
```json
{
  "success": true,
  "data": { /* endpoint-specific data */ },
  "timestamp": "2024-01-15T14:30:00Z"
}
```

### Error Response
```json
{
  "success": false,
  "message": "Error description",
  "code": "error_code",
  "documentation_url": "https://..."
}
```

### Pagination
```json
{
  "success": true,
  "data": [ /* results */ ],
  "pagination": {
    "total": 150,
    "pages": 3,
    "per_page": 10,
    "current_page": 1,
    "has_more": true
  }
}
```

---

## Endpoints

### 1. List All Jobs

Retrieve all published job listings with optional filtering and pagination.

**Request**
```
GET /jobs
```

**Query Parameters**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| per_page | int | 10 | Jobs per page (1-100) |
| page | int | 1 | Page number |
| search | string | - | Search in title/description |
| category | string | - | Filter by job category slug |
| orderby | string | date | Sort by: date, title, modified |
| order | string | DESC | ASC or DESC |

**Example Request**
```bash
curl "https://example.com/wp-json/2gunta-recruitment/v1/jobs?per_page=10&page=1&orderby=date&order=DESC"
```

**Response (200 OK)**
```json
{
  "success": true,
  "data": [
    {
      "id": 123,
      "title": "Senior PHP Developer",
      "content": "Full job description here...",
      "excerpt": "Short excerpt",
      "author": 1,
      "date": "2024-01-15T10:00:00Z",
      "modified": "2024-01-16T12:00:00Z",
      "link": "https://example.com/jobs/senior-php-developer/",
      "featured_image": "https://example.com/wp-content/uploads/job-image.jpg",
      "status": "publish",
      "meta": {
        "location": "New York, NY",
        "salary_min": 80000,
        "salary_max": 120000,
        "job_type": "Full-time",
        "experience_required": 5
      },
      "categories": [
        {
          "id": 5,
          "name": "Engineering",
          "slug": "engineering"
        }
      ],
      "application_count": 12
    }
  ],
  "pagination": {
    "total": 25,
    "pages": 3,
    "per_page": 10,
    "current_page": 1,
    "has_more": true
  },
  "timestamp": "2024-01-15T14:30:00Z"
}
```

**Error Response (400)**
```json
{
  "success": false,
  "message": "Invalid query parameters",
  "code": "invalid_parameters"
}
```

---

### 2. Get Single Job

Retrieve complete details for a specific job.

**Request**
```
GET /jobs/{id}
```

**Path Parameters**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| id | int | Yes | Job post ID |

**Example Request**
```bash
curl "https://example.com/wp-json/2gunta-recruitment/v1/jobs/123"
```

**Response (200 OK)**
```json
{
  "success": true,
  "data": {
    "id": 123,
    "title": "Senior PHP Developer",
    "content": "<h2>About the Role</h2><p>We are looking for...</p>",
    "excerpt": "Join our engineering team",
    "author": {
      "id": 1,
      "name": "Admin User",
      "email": "admin@example.com"
    },
    "date": "2024-01-15T10:00:00Z",
    "modified": "2024-01-16T12:00:00Z",
    "link": "https://example.com/jobs/senior-php-developer/",
    "featured_image": {
      "url": "https://example.com/wp-content/uploads/job-image.jpg",
      "alt": "Senior PHP Developer Position"
    },
    "status": "publish",
    "meta": {
      "location": "New York, NY",
      "salary_min": 80000,
      "salary_max": 120000,
      "job_type": "Full-time",
      "experience_required": 5,
      "remote_friendly": true,
      "benefits": "Health insurance, 401K, Remote work available"
    },
    "categories": [
      {
        "id": 5,
        "name": "Engineering",
        "slug": "engineering"
      }
    ],
    "tags": [
      {
        "id": 12,
        "name": "PHP",
        "slug": "php"
      },
      {
        "id": 13,
        "name": "WordPress",
        "slug": "wordpress"
      }
    ],
    "application_count": 12,
    "applications_url": "/wp-json/2gunta-recruitment/v1/jobs/123/applications"
  },
  "timestamp": "2024-01-15T14:30:00Z"
}
```

**Error Response (404)**
```json
{
  "success": false,
  "message": "Job not found",
  "code": "not_found",
  "documentation_url": "https://..."
}
```

---

### 3. Submit Application

Submit a new job application from a candidate.

**Request**
```
POST /apply
```

**Request Body**
```json
{
  "job_id": 123,
  "first_name": "John",
  "last_name": "Doe",
  "email": "john@example.com",
  "phone": "+1-555-0100",
  "location": "Los Angeles, CA",
  "experience_years": 5,
  "cover_letter": "I am very interested in this position because...",
  "resume_url": "https://example.com/resume.pdf",
  "gdpr_consent": true
}
```

**Field Details**
| Field | Type | Required | Constraints | Description |
|-------|------|----------|-------------|-------------|
| job_id | int | Yes | > 0 | Job post ID |
| first_name | string | Yes | 1-100 chars | Candidate first name |
| last_name | string | Yes | 1-100 chars | Candidate last name |
| email | string | Yes | Valid email | Candidate email |
| phone | string | No | Max 20 chars | Phone number |
| location | string | No | Max 100 chars | Candidate location |
| experience_years | int | No | 0-100 | Years of experience |
| cover_letter | string | No | Max 5000 chars | Cover letter text |
| resume_url | string | No | Valid URL | Resume file URL |
| gdpr_consent | boolean | No | - | GDPR data consent |

**Example Request**
```bash
curl -X POST "https://example.com/wp-json/2gunta-recruitment/v1/apply" \
  -H "Content-Type: application/json" \
  -d '{
    "job_id": 123,
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com",
    "phone": "+1-555-0100",
    "experience_years": 5,
    "gdpr_consent": true
  }'
```

**Response (201 Created)**
```json
{
  "success": true,
  "message": "Application submitted successfully",
  "data": {
    "application_id": 456,
    "candidate_id": 789,
    "job_id": 123,
    "status": "new",
    "submitted_at": "2024-01-15T14:30:00Z",
    "confirmation_email_sent": true,
    "confirmation_email_to": "john@example.com"
  },
  "timestamp": "2024-01-15T14:30:00Z"
}
```

**Error Response (400 - Validation Error)**
```json
{
  "success": false,
  "message": "Validation failed",
  "code": "validation_error",
  "errors": {
    "email": "Invalid email format",
    "phone": "Phone number is not valid"
  }
}
```

**Error Response (404 - Job Not Found)**
```json
{
  "success": false,
  "message": "Job not found",
  "code": "job_not_found"
}
```

**Error Response (409 - Duplicate Application)**
```json
{
  "success": false,
  "message": "You have already applied to this job",
  "code": "duplicate_application",
  "data": {
    "existing_application_id": 455,
    "applied_at": "2024-01-10T12:00:00Z"
  }
}
```

---

### 4. List Candidates (Admin Only)

Retrieve all candidates with optional filtering.

**Request**
```
GET /candidates
```

**Authentication**
- Requires WordPress admin login
- User must have `manage_options` capability
- Include session cookie or authentication header

**Query Parameters**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| per_page | int | 20 | Candidates per page (1-100) |
| page | int | 1 | Page number |
| search | string | - | Search in name/email |
| location | string | - | Filter by location |
| experience_min | int | - | Min years of experience |
| experience_max | int | - | Max years of experience |
| rating_min | float | - | Min candidate rating (0-5) |
| orderby | string | created | Sort by: created, rating, name |
| order | string | DESC | ASC or DESC |

**Example Request**
```bash
curl -b "wordpress_cookies.txt" \
  "https://example.com/wp-json/2gunta-recruitment/v1/candidates?per_page=20&experience_min=3"
```

or with app password:
```bash
curl -H "Authorization: Bearer username:app_password" \
  "https://example.com/wp-json/2gunta-recruitment/v1/candidates"
```

**Response (200 OK)**
```json
{
  "success": true,
  "data": [
    {
      "id": 789,
      "first_name": "John",
      "last_name": "Doe",
      "email": "john@example.com",
      "phone": "+1-555-0100",
      "location": "Los Angeles, CA",
      "experience_years": 5,
      "skills": "PHP, Laravel, WordPress, MySQL, REST APIs",
      "portfolio_url": "https://johndoe.dev",
      "rating": 4.5,
      "applications_count": 2,
      "tags": ["senior", "full-stack", "remote"],
      "created_at": "2024-01-10T12:00:00Z",
      "updated_at": "2024-01-15T14:30:00Z",
      "_links": {
        "self": "/wp-json/2gunta-recruitment/v1/candidates/789"
      }
    },
    {
      "id": 790,
      "first_name": "Jane",
      "last_name": "Smith",
      "email": "jane@example.com",
      "phone": "+1-555-0101",
      "location": "New York, NY",
      "experience_years": 7,
      "skills": "React, TypeScript, JavaScript, UI/UX, Node.js",
      "portfolio_url": "https://janesmith.design",
      "rating": 5,
      "applications_count": 3,
      "tags": ["lead", "fullstack", "ux"],
      "created_at": "2024-01-12T14:20:00Z",
      "updated_at": "2024-01-15T10:00:00Z",
      "_links": {
        "self": "/wp-json/2gunta-recruitment/v1/candidates/790"
      }
    }
  ],
  "pagination": {
    "total": 45,
    "pages": 3,
    "per_page": 20,
    "current_page": 1,
    "has_more": true
  },
  "timestamp": "2024-01-15T14:30:00Z"
}
```

**Error Response (401 - Unauthorized)**
```json
{
  "success": false,
  "message": "Authentication required",
  "code": "rest_not_logged_in"
}
```

**Error Response (403 - Insufficient Permissions)**
```json
{
  "success": false,
  "message": "You do not have permission to access this resource",
  "code": "rest_forbidden",
  "data": {
    "status": 403
  }
}
```

---

## HTTP Status Codes

| Code | Meaning | Use Case |
|------|---------|----------|
| 200 | OK | GET request successful |
| 201 | Created | Resource created (POST) |
| 204 | No Content | Successful DELETE |
| 400 | Bad Request | Invalid parameters or validation error |
| 401 | Unauthorized | Authentication required |
| 403 | Forbidden | Insufficient permissions |
| 404 | Not Found | Resource does not exist |
| 409 | Conflict | Duplicate resource (e.g., duplicate application) |
| 422 | Unprocessable Entity | Semantic error in request |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | Server error |

---

## Error Handling

### Error Response Format
```json
{
  "success": false,
  "message": "Human-readable error message",
  "code": "error_code_identifier",
  "data": {
    "additional": "error context"
  },
  "documentation_url": "https://docs.example.com/errors/error_code"
}
```

### Common Error Codes
```
validation_error          - One or more fields failed validation
job_not_found            - Referenced job does not exist
candidate_not_found      - Referenced candidate does not exist
duplicate_application    - Candidate already applied to this job
invalid_file_format      - Uploaded file not supported
file_too_large          - File exceeds size limit
rest_not_logged_in      - Authentication required
rest_forbidden          - User lacks required capability
rest_invalid_param      - Query parameter is invalid
rest_missing_callback   - Endpoint not found
```

---

## Rate Limiting

Current implementation: **No rate limiting** (recommended for production deployment)

Suggested implementation:
- Public endpoints: 100 requests per day per IP
- Apply endpoint: 5 applications per day per IP
- Admin endpoints: 1000 requests per hour per user

---

## CORS Headers

For cross-origin requests, the API includes:
```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, OPTIONS
Access-Control-Allow-Headers: Content-Type, Authorization
Access-Control-Max-Age: 3600
```

---

## Pagination Strategy

For large datasets, use cursor-based pagination:

```
GET /jobs?per_page=10&page=2

Response includes:
- total: Total number of items
- pages: Total number of pages
- current_page: Current page number
- has_more: Whether more pages exist

Navigation:
- First page: page=1
- Next page: page=current_page+1
- Last page: page=pages
```

---

## Request/Response Examples

### Complete cURL Examples

**Create Application**
```bash
curl -X POST "https://example.com/wp-json/2gunta-recruitment/v1/apply" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json" \
  -d '{
    "job_id": 123,
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com",
    "phone": "+1-555-0100",
    "experience_years": 5,
    "cover_letter": "I am interested in this role.",
    "gdpr_consent": true
  }'
```

**Get Jobs (with filters)**
```bash
curl "https://example.com/wp-json/2gunta-recruitment/v1/jobs?per_page=10&category=engineering&orderby=date"
```

**Get Candidates (as admin)**
```bash
curl -b "wordpress_session.txt" \
  "https://example.com/wp-json/2gunta-recruitment/v1/candidates?location=New%20York&experience_min=3"
```

---

## Webhooks (Future Implementation)

Planned webhook events:
- `application.submitted` - New application received
- `application.status_changed` - Application status updated
- `candidate.created` - New candidate added
- `candidate.updated` - Candidate profile changed
- `job.published` - New job published
- `job.expired` - Job posting expired

---

## API Versioning

- **Current Version:** v1
- **Base Path:** `/wp-json/2gunta-recruitment/v1`
- **Backward Compatibility:** Maintained within major versions
- **Deprecation Policy:** 12-month notice before removing endpoints

---

**API Reference Last Updated:** January 2024
**Version:** 1.0.0
**Status:** Production Ready
