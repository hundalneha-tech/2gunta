# Installation & Configuration Guide

## Quick Start (5 minutes)

### For 2gunta.com WordPress Installation

1. **Upload Plugin**
   - Upload `2gunta-recruitment` folder to `/wordpress/wp-content/plugins/`
   - Location: `/wordpress/wp-content/plugins/2gunta-recruitment/`

2. **Activate**
   - Go to WordPress admin: `https://2gunta.com/wordpress/wp-admin/`
   - Plugins → 2gunta Recruitment ATS → Click "Activate"

3. **Create Career Page**
   - Pages → Add New
   - Title: "Careers" or "Join Our Team"
   - Add this shortcode to content: `[2gunta_careers]`
   - Publish
   - (Optional) Set as homepage or add to menu

4. **Create First Job**
   - Jobs → Add New Job
   - Fill in details:
     - Title: "Senior PHP Developer"
     - Description: Job details
     - Location: "New York, NY"
     - Type: "Full-time"
   - Publish

5. **Configure Settings**
   - Jobs → Settings
   - Update email address for notifications
   - Save

**Done!** Career page is live and accepting applications.

---

## Detailed Installation

### Prerequisites Verification

Before installing, verify your system meets minimum requirements:

```bash
# Check PHP version
php -v
# Expected: PHP 7.4.0 or higher

# Check WordPress version
# WordPress admin → About WordPress
# Expected: WordPress 5.0 or higher

# Check MySQL version
# Can be found in WordPress admin → Tools → Site Health
# Expected: MySQL 5.5.5 or higher
```

### Step 1: Prepare Plugin Files

Assuming you have the plugin files locally:

```bash
# Navigate to plugin directory
cd 2gunta-recruitment-plugin/

# Verify file structure
ls -la
# Should show:
# 2gunta-recruitment.php
# README.md
# includes/
# assets/
```

### Step 2: Upload to Server

**Option A: Using FTP/SFTP (Recommended for most sites)**

1. Connect to your hosting via FTP client (e.g., FileZilla)
2. Navigate to `/wordpress/wp-content/plugins/`
3. Upload entire `2gunta-recruitment` folder
4. Verify all files are uploaded (check includes/ and assets/ folders)

**Option B: Using WordPress Admin**

1. Login to WordPress: `https://2gunta.com/wordpress/wp-admin/`
2. Plugins → Add New → Upload Plugin
3. Choose `2gunta-recruitment.zip` file
4. Click "Install Now"
5. Click "Activate Plugin"

**Option C: Using Command Line (if SSH access available)**

```bash
# SSH into server
ssh username@2gunta.com

# Navigate to plugins directory
cd public_html/wordpress/wp-content/plugins/

# Clone or copy plugin files
# (depending on your setup)
cp -r /local/path/2gunta-recruitment ./

# Verify permissions
chmod -R 755 2gunta-recruitment/
chmod -R 644 2gunta-recruitment/includes/*.php
chmod -R 644 2gunta-recruitment/assets/*
```

### Step 3: Activate Plugin

1. Login to WordPress admin: `https://2gunta.com/wordpress/wp-admin/`
2. Navigate to **Plugins**
3. Find "2gunta Recruitment ATS"
4. Click **Activate**

You should see:
- "Plugin activated successfully"
- Database tables created
- Fresh permalinks flushed

### Step 4: Verify Installation

Check that plugin is working:

1. **Check Menu Items**
   - WordPress admin left menu should show "Jobs" section
   - Sub-items: Dashboard, Add New, Applications, Candidates, Settings

2. **Check Database Tables**
   - Tools → Site Health → Info → Database
   - Look for tables: `wp_wpc_candidates`, `wp_wpc_applications`, `wp_wpc_activity_log`

3. **Check File Uploads**
   - Create test directory: `/wp-content/uploads/resumes/`
   - Folder should be created automatically

4. **Test Admin Dashboard**
   - Go to **Jobs → Dashboard**
   - Should show statistics with 0 values initially

---

## Configuration

### Initial Settings

Navigate to **Jobs → Settings** and configure:

#### Required Settings

1. **Career Page Title**
   - Default: "Careers at 2gunta"
   - This appears as the heading on your careers page
   - Recommendation: "Join Our Team" or "Careers"

2. **Recruitment Email**
   - Default: WordPress admin email
   - Email address for receiving admin notifications
   - Ensure this is checked regularly

3. **Items Per Page**
   - Default: 10
   - Number of jobs shown per page on careers page
   - Recommendation: 10 for most sites

#### File Upload Settings

4. **Maximum File Size**
   - Default: 5242880 bytes (5 MB)
   - Maximum resume file size in bytes
   - Acceptable range: 1-50 MB
   - Common sizes:
     - 5 MB = 5242880 (default)
     - 10 MB = 10485760
     - 20 MB = 20971520

5. **Allowed File Types**
   - Default: `pdf, doc, docx`
   - Comma-separated list
   - Recommended: Keep current (don't add .exe, .zip, etc.)

#### Privacy Settings

6. **Enable GDPR Compliance**
   - Default: Yes (checked)
   - Keep enabled for legal compliance
   - Ensures privacy policy integration

### Create Career Page

1. **Create New Page**
   - WordPress admin → Pages → Add New
   - Title: "Careers", "Join Our Team", or similar
   - In content editor, add: `[2gunta_careers]`
   - Publish

2. **Make It Easy to Find**
   - Add to main navigation menu
   - OR set as homepage (Settings → Reading → Static page)
   - OR link from header/footer

3. **Optional Customization**
   - Add intro text above shortcode
   - Add company benefits section below shortcode
   - Add contact information

**Example Page Content:**
```
Career Page

[2gunta_careers]

Questions? Contact us at careers@2gunta.com
```

### Configure Email Notifications

The plugin uses WordPress email capabilities. Ensure WordPress can send email:

1. **Verify SMTP Configuration**
   - Most WordPress hosts use sendmail by default
   - Test sending by submitting test application

2. **If Email Doesn't Work**
   - Install WP Mail SMTP plugin (free)
   - Configure SMTP server details
   - Test email sending

3. **Email Templates**
   - Currently hardcoded (can be customized via filters)
   - See API_REFERENCE.md for email template structure
   - To customize: Use WordPress hooks in functions.php

Example custom email template filter:
```php
// Add to WordPress theme functions.php
add_filter( '2gunta_recruitment_email_template_content', function( $content, $template ) {
    if ( $template === 'interview_invite' ) {
        $content = 'Custom interview message...';
    }
    return $content;
}, 10, 2 );
```

---

## Post-Installation Setup

### 1. Create Job Categories (Optional)

1. Jobs → Job Categories
2. Add categories like:
   - Engineering
   - Sales & Marketing
   - Operations
   - Customer Success
   - HR & Administration

These help candidates filter job listings.

### 2. Create Job Types (Optional)

1. Jobs → Job Types
2. Add job types:
   - Full-time
   - Part-time
   - Contract
   - Temporary
   - Internship

### 3. Create Sample Jobs

Create 2-3 sample jobs for testing:

1. Jobs → Add New Job
2. Title: "[SAMPLE] Senior PHP Developer"
3. Description: Job requirements and responsibilities
4. Job Details:
   - Location: Choose city
   - Job Type: Select from dropdown
   - Salary: Enter range (e.g., 80000 - 120000)
5. Category: Choose category
6. Featured Image: (Optional) Upload company/role image
7. Click Publish

Test the career page to verify jobs appear.

### 4. Update Privacy Policy

1. Settings → Privacy
2. The plugin automatically adds recruitment-related text
3. Review and customize as needed
4. Publish/Update policy

### 5. Configure Backup Settings (Recommended)

1. Tools → BackWPup (if installed)
   - Add `/wp_content/uploads/resumes/` to backup
   - Include wp_wpc_* tables in backups

---

## Advanced Configuration

### Custom Fields Extension

To add custom fields to candidate profile:

```php
// In 2gunta-recruitment-plugin/includes/class-database.php
// Add to CREATE TABLE statement:
ALTER TABLE wp_wpc_candidates ADD COLUMN custom_field VARCHAR(255);
```

Then update the form to include the field.

### Resume Parser Integration (Future)

To integrate resume parsing service (e.g., Rchilli):

1. Create wrapper class in `includes/class-resume-parser.php`
2. Integrate API calls in `class-public.php` → `handle_file_upload()`
3. Parse resume and auto-fill candidate fields

### Job Syndication (Future)

To syndicate jobs to Indeed, LinkedIn, Monster:

1. Create feed generator in `includes/class-syndication.php`
2. Implement XML feed endpoint
3. Register jobs with each job board

---

## Troubleshooting

### Plugin Not Appearing in Admin Menu

**Problem:** Jobs menu item not visible after activation

**Solutions:**
1. Hard refresh browser (Ctrl+F5)
2. Clear browser cache
3. Check user role has manage_options capability
4. Check plugin folder permissions: `chmod 755`

### Database Tables Not Created

**Problem:** Tables don't appear after activation

**Solutions:**
```bash
# Check database user permissions
# User must have CREATE TABLE privilege

# Manually create tables:
# Copy SQL from DATABASE_SCHEMA.md
# Run in phpMyAdmin → SQL tab
```

### Emails Not Sending

**Problem:** Candidates don't receive confirmation emails

**Solutions:**
1. Check SMTP configuration (Tools → Site Health)
2. Install and configure WP Mail SMTP plugin
3. Test email: Use WordPress contact form plugin to verify email works
4. Check spam/junk folders
5. Review WordPress debug log: `/wp-content/debug.log`

### Resume Upload Not Working

**Problem:** File upload fails or files not saving

**Solutions:**
1. Check folder permissions:
   ```bash
   chmod 755 /wordpress/wp-content/uploads/
   chmod 755 /wordpress/wp-content/uploads/resumes/
   ```

2. Check file size setting vs actual file
3. Verify supported formats (PDF, DOC, DOCX)
4. Check PHP upload settings in php.ini:
   - upload_max_filesize: >= 5M
   - post_max_size: >= 5M

### Career Page Shows Shortcode Instead of Jobs

**Problem:** `[2gunta_careers]` displays as text instead of loading jobs

**Solutions:**
1. Check plugin is activated (Plugins page)
2. Verify page has correct shortcode: `[2gunta_careers]` (not `[careers]`)
3. Check theme doesn't disable shortcodes (uncommon)
4. Clear all caches (if using cache plugin)

### Slow Career Page Load

**Problem:** Career page takes long to load

**Solutions:**
1. Reduce "Items Per Page" in Settings (e.g., 5 instead of 20)
2. Use caching plugin (WP Super Cache, W3 Total Cache)
3. Optimize images in job posts
4. Check database: `SELECT COUNT(*) FROM wp_wpc_applications;`
   - If > 10000, consider archiving old data

### API Returns 404

**Problem:** REST API endpoints not found

**Solutions:**
1. Verify WordPress permalinks are enabled
   - Settings → Permalinks → Select non-plain option
   - Click "Save"
   - WordPress will flush rewrite rules

2. Check plugin is activated

3. Test endpoint format:
   - Correct: `/wp-json/2gunta-recruitment/v1/jobs`
   - Incorrect: `/api/jobs` or `/json/jobs`

---

## Upgrading from Previous Versions

### From v0.9 to v1.0

1. **Backup Database First**
   ```bash
   mysqldump -u user -p database_name > backup_before_upgrade.sql
   ```

2. **Deactivate Plugin**
   - Plugins → 2gunta Recruitment ATS → Deactivate

3. **Replace Files**
   - Upload new plugin files (overwrites old)
   - Keep `/wp-content/uploads/resumes/` (existing resumes)

4. **Activate Plugin**
   - Plugins → 2gunta Recruitment ATS → Activate
   - Migration runs automatically

5. **Verify**
   - Check database tables (should have new fields)
   - Test admin dashboard
   - Test candidate form

---

## Uninstallation

### To Remove Plugin Completely

1. **Deactivate**
   - WordPress admin → Plugins → Deactivate 2gunta Recruitment ATS

2. **Delete (Option A - Keep Data)**
   - Plugins → Delete
   - Tables remain in database
   - Can reactivate later without data loss

3. **Delete (Option B - Complete Removal)**
   - Run deactivation SQL:
     ```sql
     DROP TABLE wp_wpc_candidates;
     DROP TABLE wp_wpc_applications;
     DROP TABLE wp_wpc_activity_log;
     DELETE FROM wp_options WHERE option_name LIKE '2gunta_recruitment_%';
     ```
   - Delete plugin folder: `/wordpress/wp-content/plugins/2gunta-recruitment/`

### Backup Before Uninstalling

```bash
# Export data
mysqldump -u user -p database >> backup_recruitment_data.sql

# Backup resume files
cp -r /wordpress/wp-content/uploads/resumes/ ./resumes_backup/
```

---

## Security Checklist

- [ ] WordPress updated to latest version
- [ ] All plugins updated
- [ ] PHP version >= 7.4
- [ ] SSL/HTTPS enabled
- [ ] WordPress user passwords strong
- [ ] Database user has limited privileges
- [ ] File permissions correct (644 files, 755 folders)
- [ ] wp-config.php secure (not world-readable)
- [ ] .htaccess has security rules
- [ ] Regular backups scheduled
- [ ] Monitoring/alerts configured
- [ ] GDPR compliance verified

---

## Support & Resources

- **Documentation:** See README.md, API_REFERENCE.md, DATABASE_SCHEMA.md
- **Issues:** Check troubleshooting section above
- **Contact:** support@2gunta.com
- **WordPress Docs:** https://developer.wordpress.org/
- **Plugin Security:** Follow WordPress security guidelines

---

**Installation Guide Last Updated:** January 2024
**Version:** 1.0.0
**For:** WordPress 5.0+, PHP 7.4+, MySQL 5.5.5+
