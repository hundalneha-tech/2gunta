# ⚡ QUICK START - DEPLOYMENT ONLY (5 STEPS)

## Your Plugin is Ready! Here's What to Do:

---

## 🎯 Step 1: Upload Plugin to 2gunta.com
**Location:** C:\Users\woof\2gunta-recruitment-plugin\  
**Destination:** 2gunta.com/wp-content/plugins/2gunta-recruitment-plugin/

**How:**
- Use FileZilla (FTP client) or SSH command
- Upload entire folder to WordPress plugins directory
- Takes ~2-5 minutes

---

## 🎯 Step 2: Activate in WordPress Admin
**Location:** 2gunta.com/wp-admin/  
**Steps:**
1. Log in to WordPress
2. Go to: **Plugins** (left sidebar)
3. Find: **2gunta Recruitment ATS**
4. Click: **Activate**
5. Wait for confirmation message

**Expected:** New "Jobs" menu appears in left sidebar

---

## 🎯 Step 3: Add Google API Keys
**Location:** WordPress Admin → **Jobs** → **Settings** → **Google APIs Configuration**

**Paste these keys:**
| Field | Paste This |
|-------|-----------|
| Google Maps API Key | `AIzaSyCZLboqyLKt1dVYCqnjPNKA-3SLHGUpefo` |
| Google Analytics ID | `G-B66X9RBN8T` |
| reCAPTCHA Site Key | `6LcKJ3QsAAAAAFygnbt0gY1eO9rqv5BGwD8VVuJX` |
| reCAPTCHA Secret Key | `6LcKJ3QsAAAAAMzFJc9cs57kf05BSBb8acynm1yC` |

**Then:**
- Check all 3 "Enable" checkboxes
- Click: **Save Changes**

---

## 🎯 Step 4: Create Two Pages

**Page 1:**
- Go to: **Pages** → **Add New**
- Title: `Careers`
- Content: `[2gunta_careers]`
- **Publish** and note the URL

**Page 2:**
- Go to: **Pages** → **Add New**
- Title: `Apply`
- Content: `[2gunta_application_form]`
- **Publish** and note the URL

---

## 🎯 Step 5: Test It Works
1. Visit your Careers page → Should show job listings & map
2. Click on a job → Should display job detail with interactive map
3. Click "Apply" → Should show application form
4. Submit test application → Should get confirmation email

**Done!** 🎉

---

## 📊 What You Now Have Live:

✅ **Job Listings Page** - Career page with search  
✅ **Job Details** - Interactive Google Maps showing location  
✅ **Application Form** - reCAPTCHA protected from bots  
✅ **Email Notifications** - Auto-send to candidates & admin  
✅ **Analytics Tracking** - Google Analytics funnel tracking  
✅ **Admin Dashboard** - Manage jobs, applications, candidates  

---

## 🆘 Something Wrong?

**Check:**
1. Plugin activated? (Should show "Active" status)
2. Database tables created? (Jobs → WordPress should show they exist)
3. Jobs menu visible? (Left sidebar)
4. API keys saved? (Jobs → Settings should show your keys)

**If Still Issues:**
- Check error log: `/var/log/php-errors.log`
- Disable plugin, check if WordPress loads normally
- Restore database backup if needed

---

## 💼 You're Live!

Your 2gunta Recruitment plugin is now deployed to 2gunta.com

**For detailed info:** See **LIVE_DEPLOYMENT_STEPS.md** in plugin folder  
**For testing checklist:** See **DEPLOYMENT_CHECKLIST.md** in plugin folder

---

Next: Monitor error logs and check Google Analytics after 24 hours!
