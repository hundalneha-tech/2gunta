# Database Schema Documentation

## Overview

The 2gunta Recruitment ATS plugin uses three custom database tables to manage recruitment operations. All tables are created with the WordPress table prefix (default: `wp_wpc_`).

**Database Name:** WordPress database (inherited from parent WordPress installation)
**Table Prefix:** `wp_` (or custom prefix if configured)
**Collation:** `utf8mb4_unicode_ci`
**Character Set:** `utf8mb4`

---

## Table 1: Candidates

Stores information about all job candidates.

### Table Name
```
wp_wpc_candidates
```

### Schema

| Column | Type | Null | Key | Default | Extra | Description |
|--------|------|------|-----|---------|-------|-------------|
| id | bigint(20) | NO | PK | | auto_increment | Unique candidate identifier |
| user_id | bigint(20) | YES | FK | NULL | | WordPress user ID (if linked account) |
| first_name | varchar(100) | NO | | | | Candidate first name |
| last_name | varchar(100) | NO | | | | Candidate last name |
| email | varchar(100) | NO | UQ | | | Candidate email (unique) |
| phone | varchar(20) | YES | | NULL | | Phone number with country code |
| skills | longtext | YES | | NULL | | Comma-separated skills list |
| experience_years | int(11) | YES | | NULL | | Years of professional experience |
| location | varchar(100) | YES | | NULL | | Current location/city |
| portfolio_url | varchar(255) | YES | | NULL | | Portfolio or personal website URL |
| tags | longtext | YES | | NULL | | Tags for categorization (JSON array) |
| notes | longtext | YES | | NULL | | Internal recruiter notes |
| rating | decimal(2,1) | YES | | NULL | | Candidate rating (0-5 stars) |
| created_at | datetime | NO | | CURRENT_TIMESTAMP | | Record creation timestamp |
| updated_at | datetime | NO | | CURRENT_TIMESTAMP | | Last update timestamp |

### Indexes
```sql
PRIMARY KEY (id)
UNIQUE KEY email (email)
KEY user_id (user_id)
KEY location (location)
KEY created_at (created_at)
```

### Example Query
```sql
SELECT * FROM wp_wpc_candidates 
WHERE experience_years >= 3 
  AND location = 'New York, NY' 
ORDER BY rating DESC, created_at DESC;
```

---

## Table 2: Applications

Tracks job applications from candidates to specific positions.

### Table Name
```
wp_wpc_applications
```

### Schema

| Column | Type | Null | Key | Default | Extra | Description |
|--------|------|------|-----|---------|-------|-------------|
| id | bigint(20) | NO | PK | | auto_increment | Unique application identifier |
| job_id | bigint(20) | NO | FK | | | WordPress post ID of the job |
| candidate_id | bigint(20) | NO | FK | | | Candidate ID from wp_wpc_candidates |
| resume_url | varchar(255) | YES | | NULL | | URL to uploaded resume file |
| cover_letter | longtext | YES | | NULL | | Cover letter text |
| status | varchar(50) | NO | | new | | Application status (see values below) |
| stage | varchar(50) | YES | | NULL | | Recruitment pipeline stage |
| rating | decimal(2,1) | YES | | NULL | | Application rating (0-5) |
| notes | longtext | YES | | NULL | | Internal notes about application |
| created_at | datetime | NO | | CURRENT_TIMESTAMP | | Application submission timestamp |
| updated_at | datetime | NO | | CURRENT_TIMESTAMP | | Last status change timestamp |

### Status Values
```
- new              : Just submitted, not yet reviewed
- phone-screen     : Scheduled for phone interview
- interview        : Scheduled for in-person/video interview
- offer            : Job offer extended
- hired            : Candidate accepted and hired
- rejected         : Application rejected
```

### Indexes
```sql
PRIMARY KEY (id)
KEY job_id (job_id)
KEY candidate_id (candidate_id)
KEY status (status)
KEY created_at (created_at)
FOREIGN KEY (job_id) REFERENCES wp_posts(ID)
FOREIGN KEY (candidate_id) REFERENCES wp_wpc_candidates(id)
```

### Example Query
```sql
SELECT 
  c.first_name, c.last_name, c.email,
  a.status, a.rating,
  p.post_title as job_title,
  a.created_at
FROM wp_wpc_applications a
  JOIN wp_wpc_candidates c ON a.candidate_id = c.id
  JOIN wp_posts p ON a.job_id = p.ID
WHERE p.ID = 123 
  AND a.status IN ('interview', 'offer')
ORDER BY a.rating DESC, a.created_at DESC;
```

---

## Table 3: Activity Log

Audit trail of all actions performed in the recruitment system.

### Table Name
```
wp_wpc_activity_log
```

### Schema

| Column | Type | Null | Key | Default | Extra | Description |
|--------|------|------|-----|---------|-------|-------------|
| id | bigint(20) | NO | PK | | auto_increment | Unique log entry ID |
| user_id | bigint(20) | NO | FK | | | WordPress user ID who performed action |
| candidate_id | bigint(20) | YES | FK | NULL | | Related candidate ID |
| application_id | bigint(20) | YES | FK | NULL | | Related application ID |
| action | varchar(100) | NO | | | | Action type (see values below) |
| details | longtext | YES | | NULL | | Additional action details (JSON) |
| created_at | datetime | NO | | CURRENT_TIMESTAMP | | Action timestamp |

### Action Types
```
- candidate_created        : New candidate added
- candidate_updated        : Candidate profile updated
- candidate_deleted        : Candidate removed/deleted
- application_submitted    : New application received
- application_status_changed : Application status updated
- application_deleted      : Application removed
- email_sent               : Email communication sent
- candidate_rated          : Candidate rating given
- notes_added              : Notes added to candidate/application
- export_initiated         : CSV export started
- data_deletion_requested  : GDPR data deletion requested
- data_export_requested    : GDPR data export requested
```

### Indexes
```sql
PRIMARY KEY (id)
KEY user_id (user_id)
KEY candidate_id (candidate_id)
KEY application_id (application_id)
KEY action (action)
KEY created_at (created_at)
FOREIGN KEY (user_id) REFERENCES wp_users(ID)
FOREIGN KEY (candidate_id) REFERENCES wp_wpc_candidates(id)
FOREIGN KEY (application_id) REFERENCES wp_wpc_applications(id)
```

### Example Query
```sql
SELECT 
  u.user_login as recruiter,
  a.action,
  a.details,
  a.created_at
FROM wp_wpc_activity_log a
  JOIN wp_users u ON a.user_id = u.ID
WHERE a.candidate_id = 789
  AND a.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
ORDER BY a.created_at DESC;
```

---

## Table Relationships

```
wp_users (WordPress)
  ↓
wp_wpc_activity_log (user_id)

wp_posts (WordPress - Job Custom Post Type)
  ↓
wp_wpc_applications (job_id)
  ↓
wp_wpc_candidates (candidate_id ← applications)

wp_wpc_candidates
  ↓
wp_wpc_activity_log (candidate_id)

wp_wpc_applications
  ↓
wp_wpc_activity_log (application_id)
```

---

## Custom Post Types & Taxonomies

While not traditional database tables, these WordPress post types are utilized by the plugin:

### Custom Post Type: 2gunta_job
- **Post Type Slug:** `2gunta_job`
- **Rewrite Base:** `jobs`
- **Public:** Yes (visible on frontend)
- **Hierarchical:** No
- **Supports:** title, editor, author, thumbnail, excerpt
- **Taxonomies:** job_category, job_type
- **Post Meta Fields:**
  - `_job_location` - Job location
  - `_job_salary_min` - Minimum salary
  - `_job_salary_max` - Maximum salary
  - `_job_type` - Job type (Full-time, Part-time, etc.)

### Custom Post Type: 2gunta_candidate
- **Post Type Slug:** `2gunta_candidate`
- **Public:** No (internal use only)
- **Hierarchical:** No
- **Capability Type:** post
- **Note:** Internal tracking; main data stored in wp_wpc_candidates table

### Custom Taxonomy: job_category
- **Taxonomy Slug:** `job_category`
- **Rewrite Base:** `job-category`
- **Hierarchical:** Yes (parent/child categories)
- **Associated Post Types:** 2gunta_job
- **Example Terms:** Engineering, Sales, Marketing, Operations

### Custom Taxonomy: job_type
- **Taxonomy Slug:** `job_type`
- **Rewrite Base:** `job-type`
- **Hierarchical:** Yes
- **Associated Post Types:** 2gunta_job
- **Example Terms:** Full-time, Part-time, Contract, Temporary

---

## Data Dictionary

### Candidate Ratings
- `0` = Not rated
- `1` = Poor fit
- `2` = Below average
- `3` = Average
- `4` = Good fit
- `5` = Excellent fit

### Application Stages
Pipeline stages for tracking candidate progress:
```
New → Phone Screen → Interview → Offer → Hired
                  → Rejected (at any stage)
```

### File Storage
- **Resume Storage Path:** `/wp-content/uploads/resumes/`
- **File Naming:** `candidate_{candidate_id}_{timestamp}.{ext}`
- **Supported Formats:** PDF, DOC, DOCX
- **Max Size:** 5MB (configurable)

---

## Database Maintenance

### Regular Backups
```bash
# Backup database
mysqldump -u username -p wordpress_db > backup_$(date +%Y%m%d).sql

# Backup with plugin data only
mysqldump -u username -p wordpress_db wp_wpc_* > recruitment_backup_$(date +%Y%m%d).sql
```

### Data Cleanup
```sql
-- Archive old candidates (no applications in 12 months)
SELECT id FROM wp_wpc_candidates 
WHERE id NOT IN (SELECT DISTINCT candidate_id FROM wp_wpc_applications 
                 WHERE updated_at > DATE_SUB(NOW(), INTERVAL 12 MONTH));

-- Delete old activity logs (older than 2 years)
DELETE FROM wp_wpc_activity_log 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 2 YEAR);

-- Cleanup orphaned applications
DELETE FROM wp_wpc_applications 
WHERE candidate_id NOT IN (SELECT id FROM wp_wpc_candidates);
```

### Performance Optimization
```sql
-- Check index usage
SELECT * FROM INFORMATION_SCHEMA.STATISTICS 
WHERE TABLE_SCHEMA = 'wordpress_db' 
  AND TABLE_NAME LIKE 'wp_wpc_%';

-- Rebuild tables
OPTIMIZE TABLE wp_wpc_candidates;
OPTIMIZE TABLE wp_wpc_applications;
OPTIMIZE TABLE wp_wpc_activity_log;

-- Check table sizes
SELECT 
  TABLE_NAME, 
  ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'wordpress_db' 
  AND TABLE_NAME LIKE 'wp_wpc_%'
ORDER BY (data_length + index_length) DESC;
```

---

## Security Considerations

1. **Data Encryption:** Consider encrypting sensitive fields (phone, email) for GDPR compliance
2. **Access Control:** Only administrator role can access candidate and application data
3. **Audit Logging:** All sensitive operations logged in activity_log table
4. **File Upload Security:** Resumes stored outside webroot when possible
5. **SQL Injection Prevention:** All queries use prepared statements via $wpdb
6. **Data Retention:** Implement deletion policies for compliance

---

## Export/Import

### CSV Export Format - Candidates
```
ID,First Name,Last Name,Email,Phone,Location,Experience Years,Skills,Rating,Applications,Joined Date
789,John,Doe,john@example.com,+1-555-0100,Los Angeles CA,5,"PHP, Laravel, MySQL",4.5,2,2024-01-10
```

### CSV Export Format - Applications
```
Application ID,Job Title,Candidate Name,Candidate Email,Status,Rating,Applied Date,Updated Date
456,Senior PHP Developer,John Doe,john@example.com,interview,4.5,2024-01-15,2024-01-16
```

---

## API Response Data Mapping

### Candidates Endpoint
```json
{
  "id": "wp_wpc_candidates.id",
  "first_name": "wp_wpc_candidates.first_name",
  "last_name": "wp_wpc_candidates.last_name",
  "email": "wp_wpc_candidates.email",
  "phone": "wp_wpc_candidates.phone",
  "location": "wp_wpc_candidates.location",
  "experience_years": "wp_wpc_candidates.experience_years",
  "skills": "wp_wpc_candidates.skills",
  "rating": "wp_wpc_candidates.rating",
  "applications_count": "COUNT(wp_wpc_applications)"
}
```

---

**Last Updated:** January 2024
**Version:** 1.0.0
**Schema Version:** 1.0
