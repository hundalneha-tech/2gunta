# Acceptance Criteria & Test Plan

## Overview

This document provides acceptance criteria for the 2gunta Recruitment ATS plugin based on project requirements and implementation details.

---

## AC1: Job Posting - Create & Display

**Requirement:** Recruiter should be able to create, manage, and publish job listings that appear on the public career page.

### Acceptance Criteria

- [ ] **AC1.1:** Admin can create new job via WordPress admin interface
  - **Steps:**
    1. Login as admin to WordPress dashboard
    2. Navigate to **Jobs → Add New Job**
    3. Enter job title (required)
    4. Enter job description using editor (required)
    5. Add job metadata via "Job Details" metabox:
       - Select job category
       - Select job type (Full-time, Part-time, Contract)
       - Enter location
       - Enter salary range (min/max)
    6. Click "Publish"
  - **Expected Result:** Job published successfully, appears on career page
  - **Verification:** 
    - Job appears in WordPress admin list
    - Job post status is "Publish"
    - Database contains entry in wp_posts with post_type='2gunta_job'

- [ ] **AC1.2:** Published jobs display on career page with correct information
  - **Steps:**
    1. Navigate to career page containing `[2gunta_careers]` shortcode
    2. Verify job appears in list
  - **Expected Result:** Job card displays:
    - Job title
    - Company name
    - Location
    - Job type (if available)
    - Excerpt/description
    - Apply button
  - **Verification:**
    - All fields populated correctly
    - Job details match WordPress admin entry
    - Apply button is clickable

- [ ] **AC1.3:** Job detail page shows complete job information
  - **Steps:**
    1. Click on job from career page
    2. Verify all details display
  - **Expected Result:** Job detail page includes:
    - Full job description/content
    - Location, salary range, job type
    - Company info
    - Application form
    - Share buttons (optional)
  - **Verification:**
    - URL contains job slug (e.g., /jobs/senior-php-developer/)
    - All metadata displays correctly
    - Application form loads properly

- [ ] **AC1.4:** Job search/filter functionality works
  - **Steps:**
    1. Go to career page
    2. Use search box to search for keyword (e.g., "PHP")
    3. Use filter dropdowns (category, type, location if available)
  - **Expected Result:** 
    - Search filters jobs by title/description
    - Only matching jobs display
    - Non-matching jobs are hidden
  - **Verification:**
    - Real-time filtering works
    - Results update without page refresh
    - Clear button resets filters

---

## AC2: Application Submission & Data Collection

**Requirement:** Candidates should be able to submit applications with validated information and file uploads.

### Acceptance Criteria

- [ ] **AC2.1:** Application form displays on job detail page
  - **Steps:**
    1. Navigate to any job detail page
    2. Verify application form is visible
  - **Expected Result:** Form contains fields:
    - First Name (required)
    - Last Name (required)
    - Email (required)
    - Phone (optional)
    - Location (optional)
    - Cover Letter (optional)
    - Resume upload (optional)
    - GDPR consent checkbox (required)
    - Submit button
  - **Verification:** All fields render correctly with proper labels

- [ ] **AC2.2:** Form validation prevents invalid submissions
  - **Steps:**
    1. Leave required fields empty, try to submit
    2. Enter invalid email, try to submit
    3. Upload non-PDF/DOC/DOCX file
    4. Upload file larger than 5MB
  - **Expected Result:** 
    - Form shows validation errors
    - Submission blocked with clear error messages
    - User can correct and resubmit
  - **Verification:**
    - Error messages are clear and specific
    - Inline validation displays next to fields
    - Red border/highlighting shows invalid fields

- [ ] **AC2.3:** Valid application submits successfully
  - **Steps:**
    1. Fill form with valid data:
       - First Name: "John"
       - Last Name: "Doe"
       - Email: "john@example.com"
       - Phone: "+1-555-0100"
       - Cover Letter: "I am very interested..."
       - Resume: PDF file (< 5MB)
       - GDPR: Checked
    2. Click Submit
  - **Expected Result:**
    - Form submits via AJAX without page reload
    - Success message displays
    - Confirmation email sent to candidate
  - **Verification:**
    - Entry created in wp_wpc_applications table
    - Entry created/updated in wp_wpc_candidates table
    - Email received at candidate email address
    - Activity log records "application_submitted"

- [ ] **AC2.4:** Data is correctly parsed and stored
  - **Steps:**
    1. Submit complete application
    2. Check WordPress admin Applications page
    3. Verify all data is captured
  - **Expected Result:** Admin dashboard shows:
    - Candidate name, email, phone
    - Application status
    - Submitted date
    - Resume and cover letter stored
  - **Verification:**
    - Database fields match form submission
    - Resume file uploaded to /wp-content/uploads/resumes/
    - File name doesn't expose candidate info

- [ ] **AC2.5:** Duplicate applications are prevented
  - **Steps:**
    1. Submit application as john@example.com for Job #123
    2. Try to submit another application from same email for same job
  - **Expected Result:**
    - Second submission is rejected
    - User sees message: "You have already applied to this job"
    - No duplicate entry in database
  - **Verification:**
    - Only one application record per candidate/job combination
    - System checks before creating new application

---

## AC3: Application Pipeline & Status Management

**Requirement:** Recruiters should be able to track candidates through hiring pipeline with status updates and email communication.

### Acceptance Criteria

- [ ] **AC3.1:** Application status can be changed through admin interface
  - **Steps:**
    1. Login as admin
    2. Navigate to **Jobs → Applications** or **Candidates**
    3. Find an application
    4. Click "Update Status" button
    5. Select new status from list: new, phone-screen, interview, offer, hired, rejected
    6. Click "Confirm"
  - **Expected Result:**
    - Status updates immediately in database
    - Status displays updated in admin list
    - Activity log records the change
  - **Verification:**
    - wp_wpc_applications.status field updated
    - wp_wpc_activity_log shows "application_status_changed"
    - Timestamp records when change occurred

- [ ] **AC3.2:** Interview invite email can be sent from admin
  - **Steps:**
    1. Select an application
    2. Click "Send Email"
    3. Choose email template: "Interview Invite"
    4. Verify template content and recipient
    5. Click "Send"
  - **Expected Result:**
    - Email sent to candidate
    - Email contains interview details in template
    - Candidate name substituted correctly
  - **Verification:**
    - Email received by candidate
    - Email contains: greeting with candidate name, interview details, action required
    - Activity log records "email_sent"
    - Status updated to "interview" (if configured)

- [ ] **AC3.3:** Rejection email can be sent
  - **Steps:**
    1. Select rejected application
    2. Send "Rejection" email template
  - **Expected Result:**
    - Candidate receives professional rejection email
    - Thanks candidate for applying
    - Can include message about future opportunities
  - **Verification:**
    - Email sent successfully
    - Content is professional and customizable
    - Activity log records the event

- [ ] **AC3.4:** Job offer email can be sent
  - **Steps:**
    1. Select promising application
    2. Send "Job Offer" email template
  - **Expected Result:**
    - Candidate receives job offer details
    - Email includes position, salary (if applicable), next steps
  - **Verification:**
    - Email received and formatted correctly
    - Contains all necessary offer details

- [ ] **AC3.5:** Candidates progression through pipeline is visible
  - **Steps:**
    1. View Applications list
    2. Check each application's status column
    3. Apply filters by status
  - **Expected Result:**
    - Each application shows current status
    - Can filter by status (showing only "interview" candidates, etc.)
  - **Verification:**
    - Status badges display correctly
    - Color coding differentiates statuses (green for offer, red for rejected, etc.)
    - Filter dropdown works

- [ ] **AC3.6:** Historical activity is logged
  - **Steps:**
    1. Make several status changes to an application
    2. Check activity log
  - **Expected Result:**
    - Each action recorded with timestamp
    - Shows who made the change
    - Shows what changed and to what status
  - **Verification:**
    - wp_wpc_activity_log contains complete history
    - Timestamps are in chronological order
    - User information is accurate

---

## AC4: Candidate & Application Data Export

**Requirement:** Recruiters should be able to export candidate and application data to CSV format.

### Acceptance Criteria

- [ ] **AC4.1:** Candidates can be exported to CSV
  - **Steps:**
    1. Login as admin
    2. Navigate to **Jobs → Candidates**
    3. Click "Export to CSV" button
  - **Expected Result:**
    - CSV file downloads
    - File is named "candidates_[date].csv"
    - File opens correctly in Excel/Google Sheets/Numbers
  - **Verification:**
    - CSV file downloads
    - File has headers: ID, First Name, Last Name, Email, Phone, Location, Experience, Rating, Applied
    - All candidate records included
    - File is properly formatted (commas, quotes, escaping)

- [ ] **AC4.2:** CSV contains all candidate data
  - **Steps:**
    1. Export candidates CSV
    2. Open in spreadsheet application
    3. Verify columns and data
  - **Expected Result:** CSV columns include:
    - ID
    - First Name
    - Last Name
    - Email
    - Phone
    - Location
    - Experience Years
    - Skills
    - Rating
    - Portfolio URL
    - Date Applied
  - **Verification:**
    - All fields properly exported
    - No truncated data
    - Special characters handled correctly

- [ ] **AC4.3:** Applications for specific job can be exported
  - **Steps:**
    1. Navigate to a job listing
    2. Click "Export Applications" if available
    3. Or from Applications list, filter by job and export
  - **Expected Result:**
    - Export includes only applications for selected job
    - CSV labeled with job title
  - **Verification:**
    - File downloads successfully
    - Only relevant applications included
    - File name or content indicates job reference

- [ ] **AC4.4:** Export preserves data integrity
  - **Steps:**
    1. Export candidates/applications
    2. Count records in export
    3. Compare with admin dashboard count
  - **Expected Result:**
    - Record counts match
    - No data loss or corruption
    - Formatting is readable
  - **Verification:**
    - Export row count matches database count
    - All fields present and valid
    - Can re-import data without errors

---

## AC5: GDPR Compliance & Data Management

**Requirement:** System must comply with GDPR requirements for data export and deletion.

### Acceptance Criteria

- [ ] **AC5.1:** Privacy policy includes recruitment data practices
  - **Steps:**
    1. Navigate to Privacy Policy page in WordPress
    2. Check content
  - **Expected Result:**
    - Privacy policy section added by plugin
    - Describes what data is collected
    - Explains how it's used
    - How long it's retained
  - **Verification:**
    - Plugin text appears in policy
    - Content is accurate and compliant

- [ ] **AC5.2:** Candidate data export request can be processed
  - **Steps:**
    1. Submit data export request (via WordPress privacy page)
    2. Access WordPress admin Tools → Export Personal Data
    3. Request data for candidate email
    4. Admin approves/confirms export
  - **Expected Result:**
    - Data exported in standard format (XML/CSV)
    - Contains all candidate and application records
    - Sent to candidate's email
  - **Verification:**
    - Export includes: candidate profile, all applications, timeline
    - Recipient receives downloadable file
    - Data is complete and accurate

- [ ] **AC5.3:** Candidate data deletion request can be processed
  - **Steps:**
    1. Receive data deletion request from candidate
    2. Access WordPress admin Tools → Erase Personal Data
    3. Request deletion for candidate email
    4. Admin confirms deletion
  - **Expected Result:**
    - Candidate record deleted from system
    - Related applications deleted
    - Activity log may be retained for audit
  - **Verification:**
    - wp_wpc_candidates record removed
    - Related wp_wpc_applications records removed
    - Data cannot be recovered
    - System logs the deletion action

- [ ] **AC5.4:** Consent is properly captured
  - **Steps:**
    1. Submit application
    2. Verify GDPR checkbox is required
    3. Try to submit without checking
  - **Expected Result:**
    - GDPR consent checkbox is mandatory
    - Application cannot submit without consent
    - Consent is recorded
  - **Verification:**
    - Checkbox is required
    - Submission blocked if unchecked
    - Database records consent flag

---

## AC6: REST API Functionality

**Requirement:** REST API should provide programmatic access to recruitment data with proper security.

### Acceptance Criteria

- [ ] **AC6.1:** Jobs endpoint returns correct data
  - **Steps:**
    1. Call `GET /wp-json/2gunta-recruitment/v1/jobs`
    2. Verify response
  - **Expected Result:**
    - Returns JSON array of published jobs
    - Each job includes: id, title, location, salary, type, description
    - Pagination included (total, pages, current_page)
  - **Verification:**
    - Status code 200
    - Valid JSON response
    - All fields present
    - Data matches WordPress database

- [ ] **AC6.2:** Single job endpoint returns full details
  - **Steps:**
    1. Call `GET /wp-json/2gunta-recruitment/v1/jobs/123`
    2. Verify response
  - **Expected Result:**
    - Returns single job object
    - Includes all fields + application count
    - Includes featured image if available
  - **Verification:**
    - Status code 200
    - Correct job returned
    - All fields populated

- [ ] **AC6.3:** Application submission via API works
  - **Steps:**
    1. POST to `/wp-json/2gunta-recruitment/v1/apply` with:
       ```json
       {
         "job_id": 123,
         "first_name": "John",
         "last_name": "Doe",
         "email": "john@example.com",
         "phone": "+1-555-0100",
         "gdpr_consent": true
       }
       ```
    2. Verify response
  - **Expected Result:**
    - Status code 201 (Created)
    - Response includes: application_id, status, candidate_id
    - Application stored in database
    - Confirmation email sent
  - **Verification:**
    - Record created in wp_wpc_applications
    - Candidate found/created in wp_wpc_candidates
    - Email sent successfully

- [ ] **AC6.4:** Candidates endpoint requires admin authentication
  - **Steps:**
    1. Call `GET /wp-json/2gunta-recruitment/v1/candidates` without auth
    2. Call with admin credentials
  - **Expected Result:**
    - Without auth: 401 Unauthorized
    - With auth: 200 OK with candidate data
  - **Verification:**
    - Unauthenticated request rejected
    - Authenticated request returns data
    - Non-admin role rejected

- [ ] **AC6.5:** API validates input and returns proper errors
  - **Steps:**
    1. Submit application with invalid email
    2. Submit with missing required fields
    3. Submit with file > 5MB
  - **Expected Result:**
    - Status 400 (Bad Request)
    - Error message explains problem
    - Specific field errors provided
  - **Verification:**
    - Response includes error details
    - Application not created
    - Helpful error messages guide correction

---

## Test Execution Checklist

### Pre-Test Setup
- [ ] WordPress installation ready at test site
- [ ] Plugin activated
- [ ] Database tables created
- [ ] Sample content created:
  - [ ] 5+ test jobs
  - [ ] 3+ test job categories
  - [ ] 2+ test admin users
- [ ] Email testing configured
- [ ] API testing tool ready (Postman, cURL, etc.)

### Testing Environment
- [ ] WordPress: Version 5.0+
- [ ] PHP: Version 7.4+
- [ ] MySQL: Version 5.5.5+
- [ ] Browsers tested: Chrome, Firefox, Safari, Edge
- [ ] Mobile tested: iPhone, Android

### Test Categories

#### Frontend Testing
- [ ] Career page loads correctly
- [ ] Job search/filter works
- [ ] Job detail pages display
- [ ] Application form renders
- [ ] Form validation works
- [ ] File upload works
- [ ] GDPR checkbox required
- [ ] Mobile responsive

#### Admin Testing
- [ ] Dashboard statistics display
- [ ] Create job form works
- [ ] Update job works
- [ ] Applications list displays
- [ ] Status updates work
- [ ] Email sending works
- [ ] Export CSV works
- [ ] Settings page works

#### API Testing
- [ ] GET /jobs returns data
- [ ] GET /jobs/{id} works
- [ ] POST /apply submits application
- [ ] GET /candidates requires auth
- [ ] Error handling works
- [ ] Pagination works
- [ ] Filtering works

#### Email Testing
- [ ] Application confirmation email received
- [ ] Admin notification email received
- [ ] Interview invite email received
- [ ] Rejection email received
- [ ] Offer email received
- [ ] All emails formatted correctly

#### Database Testing
- [ ] Tables created on activation
- [ ] Data persists correctly
- [ ] Foreign keys enforced
- [ ] Duplicate prevention works
- [ ] Activity log records actions
- [ ] Export functions correctly

#### Security Testing
- [ ] Nonce verification works
- [ ] Capability checks enforced
- [ ] SQL injection attempts blocked
- [ ] XSS attempts blocked
- [ ] File upload secured
- [ ] API authentication required

#### Compliance Testing
- [ ] Privacy policy updated
- [ ] Data export works
- [ ] Data deletion works
- [ ] GDPR consent captured
- [ ] No unencrypted sensitive data
- [ ] Audit logs maintained

---

## Test Results Template

```
Test Case: [AC1.1: Create Job]
Date: [Date]
Tester: [Name]
Environment: [WP Version, PHP Version, etc.]

Steps Performed:
1. [Step 1]
2. [Step 2]
3. [Step 3]

Expected Result:
[Expected outcome]

Actual Result:
[What actually happened]

Status: [ ] PASS [ ] FAIL [ ] BLOCKED

Issues Found (if any):
- [Issue 1]
- [Issue 2]

Notes:
[Additional observations]
```

---

## Known Limitations (To Be Tested)

- Maximum candidates per page: 100 (configurable)
- File upload size: 5MB (configurable)
- Resume formats: PDF, DOC, DOCX only
- No image resizing for featured images
- Email sending depends on WordPress configuration
- No built-in resume parsing

---

## Performance Baselines (Goals)

- Career page load: < 2 seconds
- Admin dashboard: < 1 second
- API response: < 500ms
- Application submission: < 2 seconds
- CSV export: < 5 seconds for 1000 records

---

## Regression Testing

After any updates, verify:
- [ ] All existing AC tests still pass
- [ ] No new bugs introduced
- [ ] Performance not degraded
- [ ] Database integrity maintained
- [ ] Email functionality not broken
- [ ] API backwards compatible

---

**Acceptance Criteria Last Updated:** January 2024
**Version:** 1.0.0
**Status:** Ready for Testing
