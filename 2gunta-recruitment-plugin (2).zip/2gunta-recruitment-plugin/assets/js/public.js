// 2gunta Recruitment - Public Frontend JavaScript

jQuery(document).ready(function($) {
    // Search jobs
    $('#job-search').on('keyup', function() {
        var searchTerm = $(this).val().toLowerCase();
        $('.job-card').each(function() {
            var text = $(this).text().toLowerCase();
            if (text.indexOf(searchTerm) > -1) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    // Handle application form submission
    $('#2gunta-application-form').on('submit', function(e) {
        e.preventDefault();

        var $form = $(this);
        var submitButton = $form.find('#submit-button');
        var originalText = submitButton.text();

        // If reCAPTCHA is enabled, get token first
        if (TwoGuntaRecruitment.recaptchaSiteKey) {
            submitButton.text('Verifying...').prop('disabled', true);
            
            grecaptcha.ready(function() {
                grecaptcha.execute(TwoGuntaRecruitment.recaptchaSiteKey, {action: 'submit'}).then(function(token) {
                    $('#recaptcha_token').val(token);
                    submitForm($form, submitButton, originalText);
                });
            });
        } else {
            submitForm($form, submitButton, originalText);
        }
    });

    function submitForm($form, submitButton, originalText) {
        var formData = new FormData($form[0]);
        formData.append('action', 'submit_application');
        formData.append('nonce', TwoGuntaRecruitment.nonce);

        $.ajax({
            url: TwoGuntaRecruitment.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                submitButton.text(originalText).prop('disabled', false);
                if (response.success) {
                    alert(response.data);
                    $form[0].reset();
                    $('#recaptcha_token').val('');
                } else {
                    alert('Error: ' + response.data);
                }
            },
            error: function() {
                submitButton.text(originalText).prop('disabled', false);
                alert('An error occurred. Please try again.');
            }
        });
    }

    // Track page views in Google Analytics
    if (typeof gtag !== 'undefined') {
        // Get current page title and path
        var pageTitle = document.title;
        var pagePath = window.location.pathname + window.location.search;
        
        // Track event
        gtag('event', 'page_view', {
            page_title: pageTitle,
            page_path: pagePath
        });

        // Track job view if on job detail page
        var jobElement = $('[data-job-id]');
        if (jobElement.length > 0) {
            var jobId = jobElement.data('job-id');
            gtag('event', 'view_item', {
                items: [{
                    item_id: jobId,
                    item_name: jobElement.data('job-title') || 'Job ' + jobId
                }]
            });
        }
    }

    // Analytics: Track form submission as conversion event (optional)
    $(document).on('submit', '#2gunta-application-form', function() {
        if (typeof gtag !== 'undefined') {
            gtag('event', 'form_submit', {
                form_destination: 'job_application'
            });
        }
