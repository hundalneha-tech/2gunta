// 2gunta Recruitment - Admin JavaScript

jQuery(document).ready(function($) {
    // Update application status
    $('.update-status-btn').on('click', function() {
        var applicationId = $(this).data('application-id');
        var newStatus = prompt('Enter new status (new, phone-screen, interview, offer, hired, rejected):');

        if (newStatus) {
            $.ajax({
                url: TwoGuntaRecruitment.ajaxurl,
                type: 'POST',
                data: {
                    action: 'update_application_status',
                    nonce: TwoGuntaRecruitment.nonce,
                    application_id: applicationId,
                    status: newStatus
                },
                success: function() {
                    location.reload();
                },
                error: function() {
                    alert('Error updating status');
                }
            });
        }
    });

    // Send email template
    $('.send-email-btn').on('click', function() {
        var applicationId = $(this).data('application-id');
        var template = $(this).data('template');

        $.ajax({
            url: TwoGuntaRecruitment.ajaxurl,
            type: 'POST',
            data: {
                action: 'send_email_template',
                nonce: TwoGuntaRecruitment.nonce,
                application_id: applicationId,
                template: template
            },
            success: function() {
                alert('Email sent successfully');
            },
            error: function() {
                alert('Error sending email');
            }
        });
    });

    // Export candidates CSV
    $('#export-candidates-btn').on('click', function() {
        $.ajax({
            url: TwoGuntaRecruitment.ajaxurl,
            type: 'POST',
            data: {
                action: 'export_candidates_csv',
                nonce: TwoGuntaRecruitment.nonce
            }
        });
    });

    // Get applications for job
    if ($('#job-applications').length) {
        var jobId = $('#job-applications').data('job-id');
        $.ajax({
            url: TwoGuntaRecruitment.ajaxurl,
            type: 'POST',
            data: {
                action: 'get_applications',
                nonce: TwoGuntaRecruitment.nonce,
                job_id: jobId
            },
            success: function(response) {
                if (response.success) {
                    var applications = response.data;
                    var html = '<table class="widefat"><thead><tr><th>Candidate</th><th>Email</th><th>Status</th><th>Actions</th></tr></thead><tbody>';

                    applications.forEach(function(app) {
                        html += '<tr><td>' + app.first_name + ' ' + app.last_name + '</td><td>' + app.email + '</td><td>' + app.status + '</td><td><button class="button update-status-btn" data-application-id="' + app.id + '">Update Status</button></td></tr>';
                    });

                    html += '</tbody></table>';
                    $('#job-applications').html(html);
                }
            }
        });
    }
});
